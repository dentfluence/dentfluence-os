<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\ApiController;
use App\Models\Activity;
use App\Models\ActionOptionList;
use App\Models\AppNotification;
use App\Models\Appointment;
use App\Models\CommunicationQueue;
use App\Models\Finance\FinancePatientMembership;
use App\Models\FollowUp;
use App\Models\Invoice;
use App\Models\LabCase;
use App\Models\Lead;
use App\Models\Patient;
use App\Models\Relationship;
use App\Models\Scopes\BranchScope;
use App\Models\Task;
use App\Models\TodayActionDismissal;
use App\Models\TreatmentOpportunity;
use App\Models\TreatmentVisit;
use App\Models\User;
use App\Modules\Huddle\Models\HuddleTaskLog;
use App\Modules\Huddle\Repositories\HuddleBoardRepository;
use App\Services\Prm\LeadFollowUpService;
use App\Services\Prm\PrmRelationshipAdapter;
use App\Services\RecallEngineService;
use App\Services\Relationship\ActivityEngine;
use App\Services\Relationship\OutcomeAutomationService;
use App\Services\Relationship\RelationshipEngine;
use App\Services\Relationship\TodayActionsEngine;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * RelationshipController (API v1)
 * --------------------------------
 * Mobile / Tulip face of PRE (the Relationship Engine — leads, opportunities,
 * recalls, and the unified relationship spine). THIN — every read/write goes
 * through the SAME services + reliable legacy columns the web PRE pages use
 * (LeadPipelineController, OpportunityPipelineController,
 * RecallPipelineController, RelationshipListController, ProfileController),
 * so behaviour never drifts between web and app. PRM no longer exists
 * anywhere in this codebase (hard-deleted 2026-07-04) — PRE is the only
 * lead/relationship engine, on web and now on mobile.
 *
 *   GET  /api/v1/relationships                       → List/search/filter (mobile equiv. of /relationship/list)
 *   GET  /api/v1/relationships/today                  → TodayActionsEngine grouped output (+ call-outcome/dismiss-reason options in meta)
 *   POST /api/v1/relationships/today/action            → Log a call outcome (mobile equiv. of TodayController::logAction, 2026-07-06 web parity)
 *   POST /api/v1/relationships/today/dismiss           → Dismiss a Today's Actions row with a reason (mobile equiv. of TodayController::dismiss, 2026-07-06 web parity)
 *   GET  /api/v1/relationships/search?q=               → Universal person search
 *   GET  /api/v1/relationships/pipelines/leads         → Lead pipeline, grouped by stage
 *   GET  /api/v1/relationships/pipelines/opportunities → Opportunity pipeline, grouped by status
 *   GET  /api/v1/relationships/pipelines/recalls       → Recall pipeline, grouped by status
 *   POST /api/v1/relationships/opportunities                    → Add an opportunity (2026-07-06 web parity)
 *   GET  /api/v1/relationships/opportunities/patient-search     → Patient autocomplete for Add Opportunity
 *   GET  /api/v1/relationships/opportunities/{id}                → Opportunity detail sheet
 *   PATCH /api/v1/relationships/opportunities/{id}/stage         → Move stage / decline (+ optional reason)
 *   POST /api/v1/relationships/opportunities/{id}/convert         → Convert opportunity to a lead
 *   POST /api/v1/relationships/recalls                 → Manually add a recall for a patient
 *   GET  /api/v1/relationships/{id}                    → Relationship profile summary (+ household)
 *   GET  /api/v1/relationships/{id}/timeline           → Paginated activity timeline
 *   GET  /api/v1/relationships/{id}/journeys           → All journeys with state
 *   POST /api/v1/relationships/{id}/activity           → Log an activity from mobile
 *   POST /api/v1/leads/quick-add                       → Quick-add a lead (4 fields)
 *   POST /api/v1/leads/{lead}/move                      → Move a lead to a different stage
 *   POST /api/v1/leads/{lead}/activity                  → Log an activity on a lead
 *   POST /api/v1/leads/{lead}/convert                    → Convert a lead to a patient
 *
 * Auth: Sanctum (via 'auth:sanctum' middleware on the api route group).
 * All routes inherit the existing Api/V1 middleware stack.
 */
class RelationshipController extends ApiController
{
    /**
     * Lead pipeline stage metadata. Kept local — mirrors
     * LeadPipelineController::STAGES (private there too) so this controller
     * never reaches into a web controller, matching this codebase's existing
     * "self-contained pipeline controller" convention.
     */
    // 2026-07-06: 'consultation' merged into 'appointment' — see
    // LeadPipelineController::STAGES (web) for the full reasoning; kept in
    // sync here for mobile parity.
    private const LEAD_STAGES = [
        'new_lead'     => ['label' => 'New Lead',     'color' => '#534AB7', 'bg' => '#EEEDFE'],
        'contacted'    => ['label' => 'Contacted',    'color' => '#0F6E56', 'bg' => '#E1F5EE'],
        'appointment'  => ['label' => 'Appointment / Consultation', 'color' => '#854F0B', 'bg' => '#FAEEDA'],
        'plan_given'   => ['label' => 'Plan Given',   'color' => '#993556', 'bg' => '#FBEAF0'],
        'converted'    => ['label' => 'Converted',    'color' => '#3B6D11', 'bg' => '#EAF3DE'],
        'lost'         => ['label' => 'Lost',         'color' => '#8A1F1F', 'bg' => '#FDECEC'],
    ];

    /** Column colours for the legacy CommunicationQueue recall statuses. */
    private const RECALL_STATUS_STYLES = [
        'pending'             => ['color' => '#854F0B', 'bg' => '#FAEEDA'],
        'waiting_for_patient' => ['color' => '#185FA5', 'bg' => '#E6F1FB'],
        'overdue'             => ['color' => '#8A1F1F', 'bg' => '#FDECEC'],
        'closed'              => ['color' => '#3B6D11', 'bg' => '#EAF3DE'],
    ];

    /** Max cards per group in a pipeline response — keeps mobile payloads light. */
    private const CARDS_PER_GROUP = 50;

    public function __construct(
        private readonly RelationshipEngine       $relationshipEngine,
        private readonly ActivityEngine           $activityEngine,
        private readonly TodayActionsEngine       $todayActionsEngine,
        private readonly OutcomeAutomationService $outcomeAutomation,
    ) {}

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Searchable, filterable, paginated browse over the whole relationship
     * base — mobile equivalent of /relationship/list (RelationshipListController).
     *
     * Query params (all optional): q, status (active|dormant|lost),
     * has (lead|patient), sort (name|score|relationship_since|created_at),
     * dir (asc|desc), page, limit (default 20, max 100).
     */
    public function list(Request $request): JsonResponse
    {
        $sorts    = ['name', 'score', 'relationship_since', 'created_at'];
        $statuses = ['active', 'dormant', 'lost'];

        $q      = trim((string) $request->query('q', ''));
        $status = in_array($request->query('status'), $statuses, true) ? $request->query('status') : null;
        $has    = in_array($request->query('has'), ['lead', 'patient'], true) ? $request->query('has') : null;
        $sort   = in_array($request->query('sort'), $sorts, true) ? $request->query('sort') : 'created_at';
        $dir    = $request->query('dir') === 'asc' ? 'asc' : 'desc';

        $query = Relationship::query();

        if ($q !== '') {
            $query->where(function ($sub) use ($q) {
                $sub->where('name', 'like', "%{$q}%")
                    ->orWhere('phone', 'like', "%{$q}%")
                    ->orWhere('email', 'like', "%{$q}%");
            });
        }

        if ($status) {
            $query->where('status', $status);
        }

        if ($has === 'lead') {
            $query->whereHas('lead');
        } elseif ($has === 'patient') {
            $query->whereHas('patient');
        }

        $limit = max(1, min((int) $request->query('limit', 20), 100));
        $page  = $query->orderBy($sort, $dir)->paginate($limit)->appends($request->query());

        $items = $page->getCollection()->map(fn (Relationship $r) => [
            'id'                 => $r->id,
            'name'               => $r->name,
            'phone'              => $r->phone,
            'email'              => $r->email,
            'score'              => $r->score,
            'status'             => $r->status,
            'source'             => $r->source,
            'relationship_since' => $r->relationship_since?->toDateString(),
        ]);

        return $this->success($items, '', 200, [
            'current_page' => $page->currentPage(),
            'per_page'     => $page->perPage(),
            'total'        => $page->total(),
            'last_page'    => $page->lastPage(),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/today
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Today's relationship actions — the mobile equivalent of /relationship/today.
     *
     * Returns the full grouped output from TodayActionsEngine so mobile can
     * display prioritised call lists by category. Each category is an array
     * of action items in the documented item shape.
     *
     * Query params:
     *   ?categories=recall_calls,lead_followups  (optional, comma-separated filter)
     */
    public function today(Request $request): JsonResponse
    {
        $actions = $this->todayActionsEngine->generate();

        // Optional category filter — mobile can ask for a subset
        if ($request->filled('categories')) {
            $allowed = array_map('trim', explode(',', $request->query('categories')));
            $actions = array_intersect_key($actions, array_flip($allowed));
        }

        // Summary counts for the mobile header bar
        $totals = [];
        $grandTotal = 0;
        foreach ($actions as $category => $items) {
            $count          = count($items);
            $totals[$category] = $count;
            $grandTotal    += $count;
        }

        return $this->success(
            $actions,
            '',
            200,
            [
                'totals'            => $totals,
                'grand_total'       => $grandTotal,
                'as_of'             => now()->toIso8601String(),
                // Call-outcome / dismiss-reason config, same source the web
                // Action Board drawer reads (Settings > Call Outcomes),
                // added 2026-07-06 for mobile parity — see logAction()/dismiss().
                'response_options'    => $this->buildResponseOptions(),
                'next_actions'        => $this->buildNextActions(),
                'requires_notes_map'  => $this->buildRequiresNotesMap(),
                'dismiss_reasons'     => ActionOptionList::query()->dismissReasons()->get()
                    ->map(fn (ActionOptionList $r) => [
                        'key'            => $r->key,
                        'label'          => $r->label,
                        'requires_notes' => (bool) $r->requires_notes,
                    ])->values(),
            ]
        );
    }

    /**
     * category => [key => label] call-outcome map. Mirrors
     * TodayController::buildResponseOptions() exactly (web parity) — starts
     * from config('relationship_rules.response_options'), then overrides any
     * category with active Settings > Call Outcomes rows.
     */
    private function buildResponseOptions(): array
    {
        $merged = config('relationship_rules.response_options', []);

        $dbRows = ActionOptionList::query()
            ->where('option_type', 'call_outcome')
            ->active()
            ->get()
            ->groupBy('action_category');

        foreach ($dbRows as $category => $rows) {
            $merged[$category] = ActionOptionList::labelMap($rows);
        }

        return $merged;
    }

    /** Mirrors TodayController::buildNextActions() exactly. */
    private function buildNextActions(): array
    {
        $overrides = ActionOptionList::query()
            ->where('option_type', 'call_outcome')
            ->whereNotNull('next_action_key')
            ->active()
            ->pluck('next_action_key', 'key')
            ->toArray();

        return array_merge(config('relationship_rules.next_actions', []), $overrides);
    }

    /** Mirrors TodayController::buildRequiresNotesMap() exactly. */
    private function buildRequiresNotesMap(): array
    {
        $rows = ActionOptionList::query()
            ->where('option_type', 'call_outcome')
            ->where('requires_notes', true)
            ->active()
            ->get(['action_category', 'key']);

        $map = [];
        foreach ($rows as $row) {
            $map[$row->action_category][$row->key] = true;
        }

        return $map;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/today/action
    // Mobile equivalent of TodayController::logAction() — same validation,
    // same ActionOptionList gate, same ActivityEngine write. 2026-07-06 parity.
    // ─────────────────────────────────────────────────────────────────────────

    public function todayLogAction(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'category'        => ['required', 'string'],
            'patient_id'      => ['nullable', 'integer'],
            'lead_id'         => ['nullable', 'integer'],
            'relationship_id' => ['nullable', 'integer'],
            'response'        => ['required', 'string'],
            'next_action'     => ['nullable', 'string'],
            'notes'           => ['nullable', 'string', 'max:500'],
        ]);

        $optionRow = ActionOptionList::query()
            ->where('option_type', 'call_outcome')
            ->where('key', $validated['response'])
            ->where(function ($q) use ($validated) {
                $q->where('action_category', $validated['category'])
                  ->orWhere('action_category', 'default');
            })
            ->active()
            ->orderByRaw('action_category = ? desc', [$validated['category']])
            ->first();

        if ($optionRow?->requires_notes && blank($validated['notes'] ?? null)) {
            return response()->json([
                'success' => false,
                'message' => 'This outcome requires a note before it can be logged.',
            ], 422);
        }

        try {
            $subject = null;
            if ($validated['patient_id']) {
                $subject = Patient::find($validated['patient_id']);
            } elseif ($validated['lead_id']) {
                $subject = Lead::find($validated['lead_id']);
            }

            if ($subject) {
                $this->activityEngine->log(
                    subject       : $subject,
                    event         : 'call.logged',
                    actor         : $request->user(),
                    metadata      : [
                        'category'    => $validated['category'],
                        'response'    => $validated['response'],
                        'next_action' => $validated['next_action'] ?? null,
                        'notes'       => $validated['notes'] ?? null,
                        'source'      => 'today_actions_mobile',
                    ],
                    relationshipId: $validated['relationship_id'] ?? null,
                    description   : 'Call logged from Today\'s Actions: ' . $validated['response'],
                );
            }

            $nextActionLabel = config('relationship_rules.next_actions.' . $validated['response'])
                ?? $validated['next_action']
                ?? 'No next action set';

            return response()->json([
                'success'           => true,
                'next_action_label' => $nextActionLabel,
            ]);
        } catch (\Throwable $e) {
            Log::error('Api/V1/RelationshipController::todayLogAction failed', [
                'data'  => $validated,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Could not log action. Please try again.',
            ], 500);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/today/dismiss
    // Mobile equivalent of TodayController::dismiss(). 2026-07-06 parity.
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * category => model class, for the live-computed categories that use
     * TodayActionDismissal. 2026-07-08: reconciled with the web
     * TodayController's map (was missing 3 categories — new_enquiries,
     * lead_followups, missed_appointments_yesterday — see
     * project_mobile_web_gap_audit_0708 memory) so Close/Dismiss behave
     * identically on mobile and web for every category.
     */
    private const DISMISSIBLE_MODELS = [
        'opportunities'                 => TreatmentOpportunity::class,
        'appointment_reminders'         => Appointment::class,
        'missed_appointments_yesterday' => Appointment::class,
        'pending_estimates'             => TreatmentOpportunity::class,
        'membership_renewals'           => FinancePatientMembership::class,
        'birthdays'                     => Patient::class,
        'lab_ready'                     => LabCase::class,
        'payment_reminders'             => Invoice::class,
        'wellness_check_yesterday'      => TreatmentVisit::class,
        'new_enquiries'                 => Lead::class,
        'lead_followups'                => Lead::class,
    ];

    /** category keys whose Today's Actions row is backed by a communication_queue record. */
    private const QUEUE_BACKED_CATEGORIES = ['recall_calls', 'missed_calls_yesterday', 'logged_communications'];

    public function todayDismiss(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'category'        => ['required', 'string'],
            'subject_id'      => ['required', 'integer'],
            'reason_key'      => ['required', 'string'],
            'notes'           => ['nullable', 'string', 'max:500'],
            'patient_id'      => ['nullable', 'integer'],
            'relationship_id' => ['nullable', 'integer'],
        ]);

        $reason = ActionOptionList::query()
            ->where('option_type', 'dismiss_reason')
            ->where('key', $validated['reason_key'])
            ->active()
            ->first();

        if (! $reason) {
            return response()->json(['success' => false, 'message' => 'Unknown dismiss reason.'], 422);
        }

        if ($reason->requires_notes && blank($validated['notes'] ?? null)) {
            return response()->json([
                'success' => false,
                'message' => 'This reason requires a note before it can be dismissed.',
            ], 422);
        }

        try {
            if ($validated['category'] === 'recall_calls' || $validated['category'] === 'missed_calls_yesterday') {
                $queueItem = CommunicationQueue::find($validated['subject_id']);
                if (! $queueItem) {
                    return response()->json(['success' => false, 'message' => 'Item not found — it may already be handled.'], 404);
                }
                $queueItem->dismiss($request->user()->id, $reason->label . ($validated['notes'] ?? '' ? ' — ' . $validated['notes'] : ''));
            } else {
                $modelClass = self::DISMISSIBLE_MODELS[$validated['category']] ?? null;
                if (! $modelClass) {
                    return response()->json(['success' => false, 'message' => 'This category cannot be dismissed.'], 422);
                }

                TodayActionDismissal::updateOrCreate(
                    [
                        'category'           => $validated['category'],
                        'subject_type'       => $modelClass,
                        'subject_id'         => $validated['subject_id'],
                        'dismissed_for_date' => \Illuminate\Support\Carbon::today()->toDateString(),
                    ],
                    [
                        'reason_key'   => $reason->key,
                        'notes'        => $validated['notes'] ?? null,
                        'dismissed_by' => $request->user()->id,
                    ]
                );
            }

            $subject = null;
            if ($request->filled('patient_id')) {
                $subject = Patient::find($request->integer('patient_id'));
            }
            if ($subject) {
                $this->activityEngine->log(
                    subject       : $subject,
                    event         : 'today_action.dismissed',
                    actor         : $request->user(),
                    metadata      : [
                        'category' => $validated['category'],
                        'reason'   => $reason->label,
                        'notes'    => $validated['notes'] ?? null,
                        'source'   => 'today_actions_mobile',
                    ],
                    relationshipId: $request->integer('relationship_id') ?: null,
                    description   : 'Dismissed from Today\'s Actions: ' . $reason->label,
                );
            }

            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            Log::error('Api/V1/RelationshipController::todayDismiss failed', [
                'data'  => $validated,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Could not dismiss item. Please try again.',
            ], 500);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/today/close
    // Mobile equivalent of TodayController::closeAction() — the explicit
    // "Close" action (2026-07-08 web parity): "I'm done with this one" after
    // however many Log attempts, no outcome required. Reuses the same
    // per-category suppression logic todayDismiss() above already needs.
    // ─────────────────────────────────────────────────────────────────────────

    public function todayClose(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'category'        => ['required', 'string'],
            'patient_id'      => ['nullable', 'integer'],
            'lead_id'         => ['nullable', 'integer'],
            'relationship_id' => ['nullable', 'integer'],
            'subject_id'      => ['nullable', 'integer'],
            'notes'           => ['nullable', 'string', 'max:500'],
        ]);

        try {
            $this->closeUnderlyingRecord(array_merge($validated, ['response' => 'closed_manually']));

            $subject = $this->resolveNoteSubject($validated['patient_id'] ?? null, $validated['lead_id'] ?? null);
            if ($subject) {
                $this->activityEngine->log(
                    subject       : $subject,
                    event         : 'today_action.closed',
                    actor         : $request->user(),
                    metadata      : [
                        'category' => $validated['category'],
                        'notes'    => $validated['notes'] ?? null,
                        'source'   => 'today_actions_mobile',
                    ],
                    relationshipId: $validated['relationship_id'] ?? null,
                    description   : "Closed from Today's Actions",
                );
            }

            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            Log::error('Api/V1/RelationshipController::todayClose failed', [
                'data'  => $validated,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Could not close. Please try again.',
            ], 500);
        }
    }

    /**
     * Mirrors TodayController::closeUnderlyingRecord() exactly (same three
     * branches: queue-backed autoClose, follow_up_calls completion, or a
     * TodayActionDismissal suppression row for everything else in
     * DISMISSIBLE_MODELS). Kept private/local rather than reaching into the
     * web controller, matching this class's existing self-contained convention.
     */
    private function closeUnderlyingRecord(array $validated): void
    {
        $category  = $validated['category'];
        $subjectId = $validated['subject_id'] ?? null;

        if (in_array($category, self::QUEUE_BACKED_CATEGORIES, true)) {
            if ($subjectId) {
                CommunicationQueue::find($subjectId)?->autoClose(
                    $validated['response'],
                    $validated['notes'] ?? "Logged from Today's Actions"
                );
            }
            return;
        }

        if ($category === 'follow_up_calls') {
            if ($subjectId) {
                FollowUp::where('id', $subjectId)->update([
                    'status'          => 'completed',
                    'completed_at'    => now(),
                    'completed_by'    => auth()->id(),
                    'completion_note' => $validated['notes'] ?? null,
                ]);
            }
            return;
        }

        $modelClass = self::DISMISSIBLE_MODELS[$category] ?? null;
        if (! $modelClass) {
            return;
        }

        $resolvedSubjectId = $modelClass === Lead::class
            ? ($validated['lead_id'] ?? $subjectId)
            : $subjectId;

        if (! $resolvedSubjectId) {
            return;
        }

        TodayActionDismissal::updateOrCreate(
            [
                'category'           => $category,
                'subject_type'       => $modelClass,
                'subject_id'         => $resolvedSubjectId,
                'dismissed_for_date' => \Illuminate\Support\Carbon::today()->toDateString(),
            ],
            [
                'reason_key'   => $validated['response'],
                'notes'        => $validated['notes'] ?? null,
                'dismissed_by' => auth()->id(),
            ]
        );
    }

    /** Patient first, then Lead — same precedence as todayLogAction()/todayDismiss(). */
    private function resolveNoteSubject(?int $patientId, ?int $leadId): ?\Illuminate\Database\Eloquent\Model
    {
        if ($patientId) {
            return Patient::find($patientId);
        }
        if ($leadId) {
            return Lead::find($leadId);
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET/POST /api/v1/relationships/today/notes
    // Mobile equivalent of TodayController::notes()/addNote() — the
    // Suggestion/Patient Response notes drawer ported from the Lead/
    // Opportunity Pipeline onto the Action Board (2026-07-08 web parity).
    // ─────────────────────────────────────────────────────────────────────────

    public function todayNotes(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'patient_id' => ['nullable', 'integer'],
            'lead_id'    => ['nullable', 'integer'],
        ]);

        $subject = $this->resolveNoteSubject($validated['patient_id'] ?? null, $validated['lead_id'] ?? null);

        if (! $subject) {
            return response()->json(['success' => true, 'notes' => []]);
        }

        $notes = Activity::query()
            ->with('actor')
            ->where('subject_type', get_class($subject))
            ->where('subject_id', $subject->getKey())
            ->ofEvent('today_action.note_added')
            ->recent()
            ->get()
            ->map(fn (Activity $note) => [
                'note_type'   => $note->metadata['note_type'] ?? 'suggestion',
                'text'        => $note->metadata['text'] ?? $note->description,
                'author'      => $note->actor?->name ?? 'Staff',
                'occurred_at' => $note->occurred_at?->format('d M Y, g:i A'),
            ]);

        return response()->json(['success' => true, 'notes' => $notes]);
    }

    public function todayAddNote(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'note_type'       => ['required', 'in:suggestion,response'],
            'text'            => ['required', 'string', 'max:1000'],
            'category'        => ['nullable', 'string'],
            'patient_id'      => ['nullable', 'integer'],
            'lead_id'         => ['nullable', 'integer'],
            'relationship_id' => ['nullable', 'integer'],
        ]);

        $subject = $this->resolveNoteSubject($validated['patient_id'] ?? null, $validated['lead_id'] ?? null);

        if (! $subject) {
            return response()->json([
                'success' => false,
                'message' => 'This item has no patient or lead attached — a note cannot be added.',
            ], 422);
        }

        $label = $validated['note_type'] === 'suggestion' ? 'Suggestion' : 'Patient response';

        $this->activityEngine->log(
            subject       : $subject,
            event         : 'today_action.note_added',
            actor         : $request->user(),
            metadata      : [
                'note_type' => $validated['note_type'],
                'text'      => $validated['text'],
                'category'  => $validated['category'] ?? null,
            ],
            relationshipId: $validated['relationship_id'] ?? null,
            description   : "{$label} added from Today's Actions: " . Str::limit($validated['text'], 80),
        );

        return response()->json(['success' => true]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/today/add-call
    // Mobile equivalent of Communication\TaskController::store()'s
    // Call/WhatsApp/Follow-up path — the "+ Add Call" button on Today's
    // Actions (2026-07-08 web parity, feature-spec-manual-add-call.md).
    // Unlike the web form this endpoint is scoped to the 3 comm categories
    // only (call/whatsapp/follow_up) since that's the only thing "+ Add Call"
    // needs to create; clinical/admin/lab/maintenance tasks still go through
    // the existing /huddle/tasks endpoint.
    // ─────────────────────────────────────────────────────────────────────────

    public function todayAddCall(Request $request): JsonResponse
    {
        $data = $request->validate([
            'title'        => 'required|string|max:255',
            'description'  => 'nullable|string|max:1000',
            'assigned_to'  => 'required|exists:users,id',
            'due_date'     => 'required|date',
            'priority'     => 'required|in:urgent,high,medium,low',
            'category'     => 'required|in:call,whatsapp,follow_up',
            'patient_id'   => 'nullable|exists:patients,id',
            'contact_name' => 'nullable|string|max:255',
            'contact_type' => 'nullable|in:vendor,lab,consultant,other',
        ]);

        $contactName = $data['contact_name'] ?? null;
        $contactType = $data['contact_type'] ?? null;
        unset($data['contact_name'], $data['contact_type']);

        $task = Task::create([
            ...$data,
            'branch_id'  => $request->user()->branch_id,
            'created_by' => $request->user()->id,
            'status'     => 'pending',
        ]);

        try {
            if ($task->patient_id) {
                FollowUp::create([
                    'patient_id'   => $task->patient_id,
                    'label'        => $task->title,
                    'note'         => $task->description,
                    'trigger_type' => 'manual',
                    'due_date'     => $task->due_date,
                    'due_time'     => $task->due_time,
                    'channel'      => $task->category === 'whatsapp' ? 'whatsapp' : 'call',
                    'priority'     => $task->priority,
                    'status'       => 'pending',
                    'assigned_to'  => $task->assigned_to,
                    'auto_created' => false,
                ]);
            } elseif ($task->category !== 'follow_up' && $contactName) {
                CommunicationQueue::create([
                    'person_name'    => $contactName,
                    'phone'          => '',
                    'channel'        => $task->category === 'whatsapp' ? 'whatsapp' : 'call',
                    'comm_type'      => $contactType === 'consultant' ? 'doctor' : ($contactType ?? 'other'),
                    'contact_type'   => $contactType ?? 'other',
                    'source_engine'  => 'manual',
                    'status'         => 'pending',
                    'priority'       => $task->priority,
                    'note'           => $task->description,
                    'follow_up_date' => $task->due_date,
                    'assigned_to'    => optional(User::find($task->assigned_to))->name,
                    'created_by'     => $request->user()->id,
                ]);
            }
        } catch (\Throwable $e) {
            Log::warning('Api mobile Task-to-CommunicationQueue/FollowUp sync failed: ' . $e->getMessage(), [
                'task_id' => $task->id,
            ]);
        }

        try {
            $assignedUser = User::find($task->assigned_to);
            if ($assignedUser) {
                $board = app(HuddleBoardRepository::class)->findOrCreateForToday(
                    branchId: $task->branch_id,
                    role:     $assignedUser->role ?? 'staff',
                );
                HuddleTaskLog::firstOrCreate(
                    ['task_id' => $task->id, 'huddle_board_id' => $board->id],
                    ['status' => 'pending', 'carried_forward' => false]
                );
            }
        } catch (\Throwable $e) {
            Log::warning('Api mobile HuddleTaskLog sync failed: ' . $e->getMessage());
        }

        if ($task->assigned_to && $task->assigned_to !== $request->user()->id) {
            AppNotification::notify(
                userId:      $task->assigned_to,
                type:        'task_assigned',
                title:       'New task assigned to you',
                message:     "\"{$task->title}\" — due {$task->due_date->format('d M Y')}. Assigned by {$request->user()->name}.",
                actionUrl:   route('tasks.index'),
                actionLabel: 'View Tasks',
            );
        }

        $task->load(['assignedTo', 'patient']);

        return response()->json([
            'success' => true,
            'task'    => [
                'id'           => $task->id,
                'title'        => $task->title,
                'priority'     => $task->priority,
                'due_date'     => $task->due_date->toDateString(),
                'assigned_to'  => $task->assignedTo?->name,
                'patient_name' => $task->patient?->name,
                'category'     => $task->category,
                'status'       => $task->status,
            ],
        ], 201);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/{id}
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Relationship profile summary — lead + patient + journeys + recent activities.
     * Reuses RelationshipEngine::getProfile() exactly as the web page does.
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $relationship = $this->findRelationship($id);

        $profile = $this->relationshipEngine->getProfile($relationship->id);

        // Household patients (mirrors ProfileController::show()'s slice-4 panel) —
        // most relationships map to a single patient; a handful share a phone
        // and link several patients. Read branch-scope-free so the whole
        // household is visible regardless of which branch each patient sits in.
        $householdPatients = Patient::withoutGlobalScope(BranchScope::class)
            ->where('relationship_id', $relationship->id)
            ->orderBy('id')
            ->get(['id', 'name', 'phone']);

        // Shape for mobile — flatten the nested Eloquent models to plain arrays
        return $this->success([
            'id'               => $relationship->id,
            'name'             => $relationship->name,
            'phone'            => $relationship->phone,
            'email'            => $relationship->email,
            'score'            => $relationship->score,
            'status'           => $relationship->status,
            'source'           => $relationship->source,
            'relationship_since' => $relationship->relationship_since?->toDateString(),
            'lead'             => $profile['lead'] ? [
                'id'    => $profile['lead']->id,
                'stage' => $profile['lead']->stage,
                'treatment' => $profile['lead']->treatment,
            ] : null,
            'patient'          => $profile['patient'] ? [
                'id'   => $profile['patient']->id,
                'name' => $profile['patient']->name,
            ] : null,
            'is_household'      => $householdPatients->count() > 1,
            'household_patients'=> $householdPatients->map(fn (Patient $p) => [
                'id'    => $p->id,
                'name'  => $p->name,
                'phone' => $p->phone,
            ])->values(),
            'journey_count'    => $profile['journeys']->count(),
            'recent_activities'=> $profile['activities']->take(10)->map(fn ($a) => [
                'id'          => $a->id,
                'event'       => $a->event,
                'description' => $a->description,
                'occurred_at' => $a->occurred_at?->toIso8601String(),
            ])->values(),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/{id}/timeline
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Paginated activity timeline for one relationship.
     *
     * Query params:
     *   ?page=1&limit=25   (default: 25 per page, max 100)
     *   ?event=call.logged (optional event filter)
     */
    public function timeline(Request $request, int $id): JsonResponse
    {
        $relationship = $this->findRelationship($id);

        $limit = max(1, min((int) $request->query('limit', 25), 100));

        $page = Activity::forRelationship($relationship->id)
            ->recent()
            ->when($request->filled('event'), fn ($q) => $q->ofEvent($request->query('event')))
            ->paginate($limit);

        $items = $page->getCollection()->map(fn (Activity $a) => [
            'id'             => $a->id,
            'event'          => $a->event,
            'description'    => $a->description,
            'actor_type'     => $a->actor_type,
            'actor_id'       => $a->actor_id,
            'subject_type'   => $a->subject_type,
            'subject_id'     => $a->subject_id,
            'metadata'       => $a->metadata,
            'occurred_at'    => $a->occurred_at?->toIso8601String(),
        ]);

        return $this->success(
            $items,
            '',
            200,
            [
                'current_page' => $page->currentPage(),
                'per_page'     => $page->perPage(),
                'total'        => $page->total(),
                'last_page'    => $page->lastPage(),
            ]
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/{id}/journeys
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * All journeys for a relationship, with current state and metadata.
     */
    public function journeys(Request $request, int $id): JsonResponse
    {
        $relationship = $this->findRelationship($id);

        $journeys = $relationship->journeys()
            ->orderByDesc('started_at')
            ->get()
            ->map(fn ($j) => [
                'id'         => $j->id,
                'type'       => $j->type,
                'state'      => $j->state,
                'started_at' => $j->started_at?->toDateString(),
                'closed_at'  => $j->closed_at?->toDateString(),
                'is_active'  => $j->closed_at === null,
                'metadata'   => $j->metadata ?? [],
            ]);

        return $this->success($journeys);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/search?q=
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Universal relationship search — name, phone, or email.
     * Returns lightweight results suitable for mobile type-ahead.
     */
    public function search(Request $request): JsonResponse
    {
        $term = trim((string) ($request->query('q') ?? ''));

        if (strlen($term) < 2) {
            return $this->success([], 'Query too short — minimum 2 characters.');
        }

        $results = Relationship::query()
            ->where(function ($q) use ($term) {
                $q->where('name',  'like', "%{$term}%")
                  ->orWhere('phone', 'like', "%{$term}%")
                  ->orWhere('email', 'like', "%{$term}%");
            })
            ->orderByDesc('score')
            ->limit(20)
            ->get()
            ->map(fn (Relationship $r) => [
                'id'     => $r->id,
                'name'   => $r->name,
                'phone'  => $r->phone,
                'email'  => $r->email,
                'score'  => $r->score,
                'status' => $r->status,
                'source' => $r->source,
            ]);

        return $this->success($results);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/{id}/activity
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Log an activity from mobile (e.g. a call outcome, note, or action taken).
     *
     * Required body:
     *   event       string   Event key in dot notation: 'call.logged', 'note.added', …
     *   description string   Human-readable summary (shown on Timeline)
     *
     * Optional body:
     *   metadata    object   Any extra context (outcome, duration, channel, …)
     *   actor_type  string   Defaults to 'App\Models\User' (the authenticated user)
     */
    public function logActivity(Request $request, int $id): JsonResponse
    {
        $relationship = $this->findRelationship($id);

        $validated = $request->validate([
            'event'       => ['required', 'string', 'max:100', 'regex:/^[a-z_]+\.[a-z_]+$/'],
            'description' => ['required', 'string', 'max:1000'],
            'metadata'    => ['nullable', 'array'],
        ]);

        // Use the Relationship itself as the subject so the activity is
        // always linked to the right record regardless of lead/patient state.
        $activity = $this->activityEngine->log(
            subject:        $relationship,
            event:          $validated['event'],
            actor:          $request->user(),
            metadata:       $validated['metadata'] ?? [],
            relationshipId: $relationship->id,
            description:    $validated['description'],
        );

        if ($activity === null) {
            return $this->error('Failed to log activity. Please try again.', [], 500);
        }

        return $this->success([
            'id'          => $activity->id,
            'event'       => $activity->event,
            'description' => $activity->description,
            'occurred_at' => $activity->occurred_at?->toIso8601String(),
        ], 'Activity logged.', 201);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/pipelines/leads
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Lead pipeline, grouped by the reliable legacy `leads.stage` column —
     * mobile equivalent of /relationship/pipeline (LeadPipelineController).
     * Shaped as groups (not kanban columns) since mobile renders this as a
     * stage-tab list, not a side-scrolling board.
     */
    public function pipelineLeads(Request $request): JsonResponse
    {
        $leads = Lead::query()
            ->select([
                'id', 'name', 'phone', 'stage', 'treatment', 'lead_value',
                'followup_date', 'assigned_to', 'urgency', 'relationship_id',
            ])
            ->orderByRaw('followup_date IS NULL, followup_date ASC')
            ->orderByDesc('id')
            ->get();

        $grouped = $leads->groupBy('stage');

        $groups = [];
        foreach (self::LEAD_STAGES as $key => $meta) {
            $bucket = $grouped->get($key, collect());
            $groups[] = [
                'key'    => $key,
                'label'  => $meta['label'],
                'color'  => $meta['color'],
                'bg'     => $meta['bg'],
                'count'  => $bucket->count(),
                'value'  => (float) $bucket->sum('lead_value'),
                'items'  => $bucket->take(self::CARDS_PER_GROUP)->map(fn (Lead $l) => [
                    'id'              => $l->id,
                    'name'            => $l->name,
                    'phone'           => $l->phone,
                    'stage'           => $l->stage,
                    'treatment'       => $l->treatment,
                    'lead_value'      => (float) $l->lead_value,
                    'followup_date'   => $l->followup_date?->toDateString(),
                    'assigned_to'     => $l->assigned_to,
                    'urgency'         => $l->urgency,
                    'relationship_id' => $l->relationship_id,
                ])->values(),
                'hidden' => max(0, $bucket->count() - self::CARDS_PER_GROUP),
            ];
        }

        $activeCount   = $leads->whereNotIn('stage', ['converted', 'lost'])->count();
        $pipelineValue = (float) $leads->whereNotIn('stage', ['converted', 'lost'])->sum('lead_value');

        return $this->success($groups, '', 200, [
            'total_leads'    => $leads->count(),
            'active_count'   => $activeCount,
            'pipeline_value' => $pipelineValue,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/pipelines/opportunities
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Opportunity pipeline, grouped by TreatmentOpportunity::STAGES — mobile
     * equivalent of /relationship/opportunities (OpportunityPipelineController).
     */
    public function pipelineOpportunities(Request $request): JsonResponse
    {
        $opportunities = TreatmentOpportunity::query()
            ->with(['relationship:id,name,phone'])
            ->select([
                'id', 'relationship_id', 'patient_id', 'type', 'label', 'status',
                'priority', 'follow_up_date', 'estimated_value', 'assigned_to',
                'declined_reason',
            ])
            ->orderByRaw('follow_up_date IS NULL, follow_up_date ASC')
            ->orderByDesc('id')
            ->get();

        $grouped = $opportunities->groupBy('status');

        $groups = [];
        foreach (TreatmentOpportunity::STAGES as $key => $meta) {
            $bucket = $grouped->get($key, collect());
            $groups[] = [
                'key'    => $key,
                'label'  => $meta['label'],
                'color'  => $meta['color'],
                'bg'     => $meta['bg'],
                'count'  => $bucket->count(),
                'value'  => (float) $bucket->sum('estimated_value'),
                'items'  => $bucket->take(self::CARDS_PER_GROUP)->map(fn (TreatmentOpportunity $o) => [
                    'id'               => $o->id,
                    'relationship_id'  => $o->relationship_id,
                    'patient_id'       => $o->patient_id,
                    'name'             => $o->relationship?->name,
                    'phone'            => $o->relationship?->phone,
                    'type'             => $o->type,
                    'label'            => $o->label,
                    'status'           => $o->status,
                    'priority'         => $o->priority,
                    'follow_up_date'   => $o->follow_up_date?->toDateString(),
                    'estimated_value'  => (float) $o->estimated_value,
                    'assigned_to'      => $o->assigned_to,
                    'declined_reason'  => $o->declined_reason,
                ])->values(),
                'hidden' => max(0, $bucket->count() - self::CARDS_PER_GROUP),
            ];
        }

        $openStatuses  = array_diff(array_keys(TreatmentOpportunity::STAGES), TreatmentOpportunity::CLOSED_STATUSES);
        $openCount     = $opportunities->whereIn('status', $openStatuses)->count();
        $pipelineValue = (float) $opportunities->whereIn('status', $openStatuses)->sum('estimated_value');

        return $this->success($groups, '', 200, [
            'total'          => $opportunities->count(),
            'open_count'     => $openCount,
            'pipeline_value' => $pipelineValue,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Opportunity lifecycle writes (2026-07-06 web parity) — mobile equivalents
    // of OpportunityPipelineController::store/patientSearch/updateStage/
    // convertToLead. Same TreatmentOpportunity table + STAGES vocabulary, same
    // effect, so behaviour never drifts between web and app.
    // ─────────────────────────────────────────────────────────────────────────

    /** POST /api/v1/relationships/opportunities — Add Opportunity sheet. */
    public function opportunityStore(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'patient_id'      => 'required|integer|exists:patients,id',
            'type'            => 'required|string|max:100',
            'label'           => 'nullable|string|max:150',
            'priority'        => 'required|in:high,medium,low',
            'estimated_value' => 'nullable|numeric|min:0',
            'follow_up_date'  => 'required|date',
            'follow_up_time'  => 'nullable|date_format:H:i',
            'assigned_to'     => 'nullable|integer|exists:users,id',
            'notes'           => 'nullable|string|max:1000',
        ]);

        $patient        = Patient::find($validated['patient_id']);
        $relationshipId = $patient?->relationship_id;

        $opportunity = TreatmentOpportunity::create([
            ...$validated,
            'relationship_id' => $relationshipId,
            'status'          => 'prospect',   // always starts at Identified
            'created_by'      => $request->user()->id,
        ]);

        return $this->success(['id' => $opportunity->id], 'Opportunity added.', 201);
    }

    /** GET /api/v1/relationships/opportunities/patient-search?q= */
    public function opportunityPatientSearch(Request $request): JsonResponse
    {
        $term = trim((string) $request->query('q', ''));

        $patients = Patient::where(function ($q) use ($term) {
                $q->where('name', 'like', "%{$term}%")
                  ->orWhere('phone', 'like', "%{$term}%");
            })
            ->limit(10)
            ->get(['id', 'name', 'phone']);

        return $this->success($patients);
    }

    /** GET /api/v1/relationships/opportunities/{id} — full detail sheet. */
    public function opportunityShow(int $id): JsonResponse
    {
        $opportunity = TreatmentOpportunity::with(['patient', 'assignedStaff', 'author', 'treatmentPlan'])
            ->findOrFail($id);

        $stageInfo = TreatmentOpportunity::STAGES[$opportunity->status] ?? [];

        return $this->success([
            'id'               => $opportunity->id,
            'patient_id'       => $opportunity->patient_id,
            'patient_name'     => $opportunity->patient->name ?? 'Unknown',
            'patient_phone'    => $opportunity->patient->phone ?? null,
            'type'             => $opportunity->type,
            'display_label'    => $opportunity->display_label,
            'status'           => $opportunity->status,
            'stage_label'      => $stageInfo['label'] ?? $opportunity->status,
            'priority'         => $opportunity->priority,
            'priority_label'   => $opportunity->priority_label,
            'estimated_value'  => (float) $opportunity->estimated_value,
            'follow_up_date'   => $opportunity->follow_up_date?->toDateString(),
            'follow_up_time'   => $opportunity->follow_up_time,
            'assigned_to'      => $opportunity->assigned_to,
            'assigned_to_name' => $opportunity->assignedStaff?->name,
            'created_by_name'  => $opportunity->author?->name,
            'notes'            => $opportunity->notes,
            'declined_reason'  => $opportunity->declined_reason,
            'created_at'       => $opportunity->created_at?->toIso8601String(),
            'updated_at'       => $opportunity->updated_at?->toIso8601String(),
            'treatment_plan'   => $opportunity->treatmentPlan ? [
                'id'    => $opportunity->treatmentPlan->id,
                'name'  => $opportunity->treatmentPlan->plan_name ?? ('Treatment Plan #' . $opportunity->treatment_plan_id),
                'total' => (float) ($opportunity->treatmentPlan->total ?? 0),
            ] : null,
        ]);
    }

    /**
     * PATCH /api/v1/relationships/opportunities/{id}/stage — move-stage /
     * decline. `reason` is optional free text, only saved when moving to
     * 'declined' (skippable — a decline with no reason is fine).
     */
    public function opportunityUpdateStage(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'status' => 'required|in:prospect,discussed,quoted,accepted,completed,declined',
            'reason' => 'nullable|string|max:1000',
        ]);

        $opp = TreatmentOpportunity::findOrFail($id);

        $update = ['status' => $request->input('status')];
        if ($request->input('status') === 'declined') {
            $update['declined_reason'] = $request->filled('reason') ? $request->input('reason') : null;
        }
        $opp->update($update);

        $stageInfo = TreatmentOpportunity::STAGES[$request->input('status')] ?? [];

        return $this->success([
            'id'          => $opp->id,
            'status'      => $opp->status,
            'stage_label' => $stageInfo['label'] ?? $opp->status,
        ], 'Opportunity moved to ' . ($stageInfo['label'] ?? $opp->status) . '.');
    }

    /**
     * POST /api/v1/relationships/opportunities/{id}/convert — Convert to Lead
     * modal. Creates a Lead in the chosen starting stage and marks the
     * opportunity completed (same effect as OpportunityPipelineController::
     * convertToLead()).
     */
    public function opportunityConvert(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'stage'       => 'nullable|string|max:50',
            'assigned_to' => 'nullable|integer|exists:users,id',
        ]);

        $opp = TreatmentOpportunity::with(['patient', 'assignedStaff'])->findOrFail($id);

        $leadId = DB::transaction(function () use ($opp, $request) {
            // 2026-07-06 bug fix — see OpportunityPipelineController::convertToLead()
            // for the full reasoning: don't overload 'completed'/Converted with
            // "sent to a Lead instead" — that's a different real event and it was
            // corrupting the Converted (MTD) figure. Stage is left untouched;
            // the conversion is logged to the Timeline instead.
            app(ActivityEngine::class)->log(
                subject       : $opp,
                event         : 'opportunity.sent_to_lead',
                actor         : $request->user(),
                metadata      : ['opportunity_id' => $opp->id],
                relationshipId: $opp->relationship_id,
                description   : "Opportunity #{$opp->id} sent to Lead Pipeline as a new lead (stage left unchanged).",
            );

            $assignedName = $request->filled('assigned_to')
                ? User::find($request->input('assigned_to'))?->name
                : $opp->assignedStaff?->name;

            $lead = Lead::create([
                'name'        => $opp->patient->name ?? 'Unknown',
                'phone'       => $opp->patient->phone ?? '',
                'stage'       => $request->input('stage') ?: 'new',
                'lead_source' => 'referral',
                'source'      => 'opportunity',
                'treatment'   => $opp->display_label,
                'lead_value'  => $opp->estimated_value,
                'assigned_to' => $assignedName,
                'notes'       => "Converted from Treatment Opportunity #{$opp->id}.\n\n" . ($opp->notes ?? ''),
            ]);

            return $lead->id;
        });

        return $this->success(['lead_id' => $leadId], 'Opportunity converted to a lead in the Lead Pipeline.');
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/pipelines/recalls
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Recall pipeline, grouped by CommunicationQueue::STATUSES — mobile
     * equivalent of /relationship/recalls (RecallPipelineController).
     */
    public function pipelineRecalls(Request $request): JsonResponse
    {
        $recalls = CommunicationQueue::query()
            ->where(function ($q) {
                $q->where('purpose', 'recall')->orWhere('source_engine', 'recall');
            })
            ->select([
                'id', 'person_name', 'phone', 'channel', 'status', 'priority',
                'follow_up_date', 'due_at', 'attempt_count', 'assigned_to', 'is_overdue',
            ])
            ->orderByRaw('follow_up_date IS NULL, follow_up_date ASC')
            ->orderByDesc('id')
            ->get();

        $grouped = $recalls->groupBy('status');

        $groups = [];
        foreach (CommunicationQueue::STATUSES as $key => $label) {
            $bucket = $grouped->get($key, collect());
            $groups[] = [
                'key'    => $key,
                'label'  => $label,
                'color'  => self::RECALL_STATUS_STYLES[$key]['color'] ?? '#534AB7',
                'bg'     => self::RECALL_STATUS_STYLES[$key]['bg'] ?? '#EEEDFE',
                'count'  => $bucket->count(),
                'items'  => $bucket->take(self::CARDS_PER_GROUP)->map(fn (CommunicationQueue $c) => [
                    'id'             => $c->id,
                    'person_name'    => $c->person_name,
                    'phone'          => $c->phone,
                    'channel'        => $c->channel,
                    'status'         => $c->status,
                    'priority'       => $c->priority,
                    'follow_up_date' => $c->follow_up_date?->toDateString(),
                    'due_at'         => $c->due_at?->toIso8601String(),
                    'attempt_count'  => $c->attempt_count,
                    'assigned_to'    => $c->assigned_to,
                    'is_overdue'     => (bool) $c->is_overdue,
                ])->values(),
                'hidden' => max(0, $bucket->count() - self::CARDS_PER_GROUP),
            ];
        }

        $openCount    = $recalls->where('status', '!=', 'closed')->count();
        $overdueCount = $recalls->filter(fn ($r) => $r->is_overdue || $r->status === 'overdue')->count();

        return $this->success($groups, '', 200, [
            'total'         => $recalls->count(),
            'open_count'    => $openCount,
            'overdue_count' => $overdueCount,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/recalls
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Manually add a recall for a patient — mobile equivalent of
     * RecallPipelineController::store(). Same table, same tagging
     * ('manual', distinct from the 6 automated triggers), shows up on the
     * recall board and Today's Actions exactly like any other recall.
     */
    public function recallStore(Request $request): JsonResponse
    {
        $data = $request->validate([
            'patient_id'     => ['required', 'integer', 'exists:patients,id'],
            'priority'       => ['required', 'in:high,medium,low'],
            'follow_up_date' => ['required', 'date'],
            'note'           => ['nullable', 'string', 'max:500'],
        ]);

        $patient = Patient::findOrFail($data['patient_id']);

        if (! $patient->phone) {
            return $this->error('This patient has no phone number on file — add one before creating a recall.', [], 422);
        }

        app(RecallEngineService::class)->createManual($patient, $data);

        return $this->success(null, 'Recall added for ' . $patient->name . '.', 201);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET /api/v1/relationships/call-outcomes
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Grouped call-outcome vocabulary for the Activity Completion Bottom
     * Sheet (mobile + web). Static reference data — no query, safe to cache
     * client-side.
     */
    public function callOutcomes(Request $request): JsonResponse
    {
        return $this->success(
            collect(CommunicationQueue::callOutcomeGroups())
                ->map(fn (array $group) => collect($group)->map(
                    fn (string $label, string $key) => ['key' => $key, 'label' => $label]
                )->values())
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST /api/v1/relationships/recalls/{queueId}/complete
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Complete a recall via the Activity Completion Bottom Sheet: records the
     * call outcome + notes + next follow-up date, then runs the matching PRE
     * automation (OutcomeAutomationService) — create appointment, close
     * recall, schedule follow-up, mark invalid contact, disable automations,
     * etc. One engine shared by web and mobile so behaviour never drifts.
     *
     * Required body:  outcome (string, see /call-outcomes for valid keys)
     * Optional body:  notes, next_follow_up_date (date),
     *                 doctor_id, appointment_date, appointment_time
     *                 (only consumed when outcome = appointment_booked)
     */
    public function recallComplete(Request $request, int $queueId): JsonResponse
    {
        $comm = CommunicationQueue::findOrFail($queueId);

        $validated = $request->validate([
            'outcome'              => ['required', 'string', 'in:' . implode(',', array_keys(CommunicationQueue::allCallOutcomes()))],
            'notes'                => ['nullable', 'string', 'max:1000'],
            'next_follow_up_date'  => ['nullable', 'date'],
            'doctor_id'            => ['nullable', 'integer', 'exists:users,id'],
            'appointment_date'     => ['nullable', 'date'],
            'appointment_time'     => ['nullable', 'string'],
        ]);

        $result = $this->outcomeAutomation->apply(
            comm:    $comm,
            outcome: $validated['outcome'],
            actor:   $request->user(),
            options: [
                'notes'                => $validated['notes']               ?? null,
                'next_follow_up_date'  => $validated['next_follow_up_date'] ?? null,
                'doctor_id'            => $validated['doctor_id']           ?? null,
                'appointment_date'     => $validated['appointment_date']    ?? null,
                'appointment_time'     => $validated['appointment_time']    ?? null,
            ],
        );

        return $this->success($result, 'Activity logged.', 201);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Lead lifecycle writes — mobile equivalents of LeadPipelineController's
    // Phase 8 writes (moveStage / logActivity / convertToPatient / quick-add).
    // Same effect, same relationship-spine mirroring via PrmRelationshipAdapter
    // (name kept post-PRM-retirement — it's the shared spine-writing
    // primitive, not a PRM-specific class).
    // ─────────────────────────────────────────────────────────────────────────

    /** POST /api/v1/leads/{lead}/move */
    public function leadMoveStage(Request $request, int $lead): JsonResponse
    {
        $request->validate(['stage' => 'required|string']);

        $leadModel = Lead::findOrFail($lead);
        $oldStage  = $leadModel->stage;
        $newStage  = $request->input('stage');

        $leadModel->update(['stage' => $newStage]);

        $leadModel->activities()->create([
            'type'          => 'stage_change',
            'label'         => 'Stage Changed',
            'note'          => "Moved from {$oldStage} → {$newStage}",
            'activity_date' => today(),
            'activity_time' => now()->format('h:i A'),
            'by'            => $request->user()->name ?? 'Staff',
        ]);

        $created = app(LeadFollowUpService::class)->createForStage($leadModel, $newStage);

        app(PrmRelationshipAdapter::class)->onStageChanged($leadModel, $oldStage, $newStage, $request->user());

        return $this->success(['followups_created' => $created], 'Lead moved to ' . $newStage . '.');
    }

    /** POST /api/v1/leads/{lead}/activity */
    public function leadLogActivity(Request $request, int $lead): JsonResponse
    {
        $validated = $request->validate([
            'type'    => 'required|string',
            'label'   => 'required|string',
            'note'    => 'nullable|string',
            'outcome' => 'nullable|string',
        ]);

        $leadModel = Lead::findOrFail($lead);

        $activity = $leadModel->activities()->create([
            'type'          => $validated['type'],
            'label'         => $validated['label'],
            'outcome'       => $validated['outcome'] ?? null,
            'note'          => $validated['note'] ?? null,
            'activity_date' => today(),
            'activity_time' => now()->format('h:i A'),
            'by'            => $request->user()->name ?? 'Staff',
        ]);

        app(PrmRelationshipAdapter::class)->onActivityLogged(
            $leadModel, $validated['type'], $validated['label'], $validated['note'] ?? null,
            $validated['outcome'] ?? null, $request->user(),
        );

        return $this->success(['id' => $activity->id], 'Activity logged.', 201);
    }

    /** POST /api/v1/leads/{lead}/convert */
    public function leadConvert(Request $request, int $lead): JsonResponse
    {
        $leadModel = Lead::findOrFail($lead);
        $leadModel->update(['stage' => 'converted']);

        $leadModel->activities()->create([
            'type'          => 'stage_change',
            'label'         => 'Converted to Patient',
            'note'          => 'Lead marked as converted.',
            'activity_date' => today(),
            'activity_time' => now()->format('h:i A'),
            'by'            => $request->user()->name ?? 'Staff',
        ]);

        // Reuse the Patient already linked to this lead's Relationship, if any —
        // avoids creating a duplicate when a lead is converted more than once.
        $patient = $leadModel->relationship_id
            ? Patient::where('relationship_id', $leadModel->relationship_id)->first()
            : null;

        if (! $patient) {
            // Canonical mint — every registration goes through PatientService::register().
            $patient = app(\App\Services\PatientService::class)->register([
                'name'            => $leadModel->name,
                'phone'           => $leadModel->phone,
                'alternate_phone' => $leadModel->alt_phone,
                'email'           => $leadModel->email,
                'date_of_birth'   => $leadModel->dob,
                'gender'          => $leadModel->gender,
                'occupation'      => $leadModel->occupation,
                'area'            => $leadModel->location,
                'referred_by'     => $leadModel->referred_by,
                'source'          => $leadModel->source ?: $leadModel->lead_source,
                'chief_complaint' => $leadModel->treatment,
            ], $request->user());

            // Reuse the lead's authoritative relationship link (overrides the
            // flag-gated fuzzy linker register() runs; a no-op when off).
            if ($leadModel->relationship_id) {
                $patient->relationship_id = $leadModel->relationship_id;
                $patient->save();
            }
        }

        app(PrmRelationshipAdapter::class)->onConverted($leadModel, $request->user());

        return $this->success(['patient_id' => $patient->id], 'Lead converted to patient.');
    }

    /**
     * GET /api/v1/leads/{lead}/detail — Lead Detail modal, mobile equivalent
     * of LeadPipelineController::detailModal() (2026-07-08 web parity). Reads
     * straight off Lead::activities() (LeadActivity's `by` column already
     * stores who logged it), so this works even for leads with no
     * relationship_id — same as the web modal. No new write path: activity
     * logging already exists at POST /api/v1/leads/{lead}/activity above.
     */
    public function leadDetail(int $lead): JsonResponse
    {
        $leadModel = Lead::with(['activities' => fn ($q) => $q->latest('id')])->findOrFail($lead);

        $stageInfo = self::LEAD_STAGES[$leadModel->stage] ?? [];

        return $this->success([
            'id'              => $leadModel->id,
            'name'            => $leadModel->name,
            'phone'           => $leadModel->phone,
            'stage'           => $leadModel->stage,
            'stage_label'     => $stageInfo['label'] ?? $leadModel->stage,
            'stage_color'     => $stageInfo['color'] ?? null,
            'stage_bg'        => $stageInfo['bg'] ?? null,
            'treatment'       => $leadModel->treatment,
            'lead_value'      => (float) $leadModel->lead_value,
            'urgency'         => $leadModel->urgency,
            'followup_date'   => $leadModel->followup_date?->toDateString(),
            'assigned_to'     => $leadModel->assigned_to,
            'source'          => $leadModel->source,
            'lead_source'     => $leadModel->lead_source,
            'notes'           => $leadModel->notes,
            'relationship_id' => $leadModel->relationship_id,
            'created_at'      => $leadModel->created_at?->toIso8601String(),
            'updated_at'      => $leadModel->updated_at?->toIso8601String(),
            'activities'      => $leadModel->activities->map(fn ($a) => [
                'type'          => $a->type,
                'label'         => $a->label,
                'note'          => $a->note,
                'outcome'       => $a->outcome,
                'by'            => $a->by,
                'activity_date' => $a->activity_date?->toDateString(),
                'activity_time' => $a->activity_time,
            ])->values(),
        ]);
    }

    /** POST /api/v1/leads/quick-add — 4-field quick add (name/phone/lead_source/treatment). */
    public function leadQuickAdd(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'        => 'required|string|max:120',
            'phone'       => 'required|string|max:20',
            'lead_source' => 'required|string|max:50',
            'treatment'   => 'nullable|string',
        ]);

        $data['stage']  = 'new_lead';
        $data['source'] = Lead::LEAD_SOURCES[$data['lead_source']] ?? $data['lead_source'];

        $leadModel = Lead::create($data);

        $leadModel->activities()->create([
            'type'          => 'note',
            'label'         => 'Lead Created (Quick Add)',
            'note'          => "Added via Quick Add. Source: {$data['source']}.",
            'activity_date' => today(),
            'activity_time' => now()->format('h:i A'),
            'by'            => $request->user()->name ?? 'Staff',
        ]);

        return $this->success(['id' => $leadModel->id], 'Lead added.', 201);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Resolve a Relationship by ID. Throws a clean enveloped 404 on miss.
     * We do NOT scope to branch here — Relationships are clinic-wide records.
     */
    private function findRelationship(int $id): Relationship
    {
        $relationship = Relationship::find($id);

        if (! $relationship) {
            throw new HttpResponseException(response()->json([
                'success' => false,
                'message' => 'Relationship not found.',
                'errors'  => [],
            ], 404));
        }

        return $relationship;
    }
}
