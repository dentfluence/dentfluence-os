<?php

namespace App\Http\Controllers;

use App\Models\BillingAuditLog;
use App\Models\EmiProvider;
use App\Models\EmiScheme;
use App\Models\EmiSchedule;
use App\Models\BillingPrompt;
use App\Models\CouponCode;
use App\Models\CouponUsage;
use App\Models\FinalBill;
use App\Models\Finance\FinanceBankAccount;
use App\Models\Finance\FinanceMembershipPlan;
use App\Models\Finance\FinanceTransaction;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\InvoicePayment;
use App\Models\Inventory\InventoryItem;
use App\Models\Inventory\InventoryLocation;
use App\Models\Inventory\StockMovement;
use App\Models\Patient;
use App\Models\Receipt;
use App\Models\Treatment;
use App\Models\TreatmentPlan;
use App\Models\TreatmentVisitItem;
use App\Services\Billing\PlanBillingRollbackService;
use App\Services\Billing\TreatmentPlanBillingService;
use App\Models\Wallet;
use App\Services\MembershipBenefitService;
use App\Services\Billing\PatientPaymentAllocationService;
use App\Services\Billing\PatientPaymentVoidService;
use App\Services\WalletService;
use App\Services\CouponService;
use App\Services\Relationship\ActivityEngine;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class BillingController extends Controller
{
    use \App\Http\Controllers\Concerns\ChecksStaleUpdates;

    // ── Index ────────────────────────────────────────────────────────────────

    public function index(Request $request)
    {
        $query = Invoice::with('patient')
            ->orderByDesc('invoice_date')
            ->orderByDesc('id');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->whereHas('patient', fn($p) => $p->where('name', 'like', "%{$s}%")
                                                      ->orWhere('phone', 'like', "%{$s}%"))
                  ->orWhere('invoice_number', 'like', "%{$s}%");
            });
        }

        $invoices = $query->paginate(20)->withQueryString();

        $summary = Invoice::selectRaw("
            COUNT(*) as total,
            SUM(total_amount) as total_billed,
            SUM(paid_amount) as total_collected,
            SUM(balance_due) as total_outstanding
        ")->first();

        return view('billing.index', compact('invoices', 'summary'));
    }

    // ── Create (generic) ────────────────────────────────────────────────────

    public function create(Request $request)
    {
        $patients        = Patient::orderBy('name')->get(['id', 'name', 'phone']);
        $treatments      = Treatment::where('is_active', true)->orderBy('name')->get(['id', 'name', 'default_price', 'gst_pct', 'unit_basis']);
        // withSum so the picker can warn/block on out-of-stock items client-side
        // rather than silently letting stock go negative at invoice save time.
        $sellableProducts = InventoryItem::sellable()->orderBy('product_name')
            ->withSum('stocks', 'available_qty')
            ->get(['id', 'product_name', 'mrp', 'gst_rate']);
        $invoice         = null;
        $selectedPatient = $request->filled('patient_id') ? Patient::find($request->patient_id) : null;
        $preloadedItems  = collect();
        $pendingPrompts  = collect();
        $wallet          = null;

        $membershipInfo = null;

        if ($selectedPatient) {
            $pendingPrompts = BillingPrompt::with('invoice')
                ->forPatient($selectedPatient->id)
                ->pending()
                ->latest()
                ->get();
            $wallet = Wallet::forPatient($selectedPatient->id);
            $membershipInfo = MembershipBenefitService::forPatient($selectedPatient->id);
        }

        return view('billing.form', compact(
            'patients', 'treatments', 'sellableProducts', 'invoice', 'selectedPatient',
            'preloadedItems', 'pendingPrompts', 'wallet', 'membershipInfo'
        ));
    }

    // ── Create from Billing Prompt ───────────────────────────────────────────
    // Front desk clicks "Build Invoice" on a pending billing prompt.
    // We open the invoice form as an EDITABLE DRAFT, pre-filled with the visit's
    // line items (added automatically as rows — no manual treatment picking).
    // Staff can tweak prices/qty/discounts, then hit Save to create the invoice.

    public function createFromPrompt(Patient $patient, BillingPrompt $prompt)
    {
        if ($prompt->patient_id !== $patient->id) {
            abort(403, 'Prompt does not belong to this patient.');
        }

        // Already invoiced/dismissed? Don't reopen — jump to the linked invoice
        // if there is one, otherwise return to the patient.
        if ($prompt->status !== 'pending') {
            if ($prompt->invoice_id) {
                return redirect()->route('billing.show', $prompt->invoice_id)
                    ->with('info', 'This prompt was already invoiced.');
            }
            return redirect()->route('patients.show', $patient)
                ->with('error', 'This billing prompt is no longer pending.');
        }

        // Pull the pending line items recorded against the triggering visit.
        // Prompts fired by a completed visit use trigger_type 'treatment_visit'
        // with trigger_id = treatment_visit.id. These pre-fill the form as rows.
        $preloadedItems = collect();
        if ($prompt->trigger_type === 'treatment_visit' && $prompt->trigger_id) {
            $preloadedItems = TreatmentVisitItem::where('patient_id', $patient->id)
                ->where('treatment_visit_id', $prompt->trigger_id)
                ->where('billing_status', 'pending')
                ->get();
        }

        $patients   = Patient::orderBy('name')->get(['id', 'name', 'phone']);
        $treatments = Treatment::where('is_active', true)->orderBy('name')->get(['id', 'name', 'default_price', 'gst_pct', 'unit_basis']);
        // withSum so the picker can warn/block on out-of-stock items client-side
        // rather than silently letting stock go negative at invoice save time.
        $sellableProducts = InventoryItem::sellable()->orderBy('product_name')
            ->withSum('stocks', 'available_qty')
            ->get(['id', 'product_name', 'mrp', 'gst_rate']);
        $invoice    = null;

        // All pending prompts for this patient (so the form can show context)
        $pendingPrompts = BillingPrompt::forPatient($patient->id)->pending()->latest()->get();

        // Wallet balance
        $wallet = Wallet::forPatient($patient->id);

        // Membership auto-apply (recalculated client-side as items change)
        $membershipInfo = MembershipBenefitService::forPatient($patient->id);

        $selectedPatient = $patient;

        return view('billing.form', compact(
            'patients', 'treatments', 'sellableProducts', 'invoice',
            'selectedPatient', 'preloadedItems', 'pendingPrompts',
            'wallet', 'prompt', 'membershipInfo'
        ));
    }

    // ── Dismiss Prompt ──────────────────────────────────────────────────────

    public function dismissPrompt(BillingPrompt $prompt)
    {
        $prompt->dismiss(auth()->id());

        return back()->with('success', 'Billing prompt dismissed.');
    }

    // ── AJAX: Validate Coupon ────────────────────────────────────────────────
    // Called by the invoice form via fetch() when the user enters a code.
    // Returns JSON: { valid, discount_type, discount_value, label, error? }

    public function validateCoupon(Request $request)
    {
        $request->validate(['code' => 'required|string', 'subtotal' => 'required|numeric|min:0']);

        $coupon = CouponCode::active()->where('code', strtoupper(trim($request->code)))->first();

        if (!$coupon) {
            return response()->json(['valid' => false, 'error' => 'Coupon code not found or expired.']);
        }

        $patientId = $request->patient_id;
        if ($patientId && !$coupon->canBeUsedByPatient((int) $patientId)) {
            return response()->json(['valid' => false, 'error' => 'This coupon has already been used the maximum number of times for this patient.']);
        }

        if ((float) $request->subtotal < (float) $coupon->min_invoice_amount) {
            return response()->json([
                'valid' => false,
                'error' => 'Minimum invoice amount for this coupon is Rs. ' . number_format((float) $coupon->min_invoice_amount, 0) . '.',
            ]);
        }

        $discountAmount = $coupon->calculateDiscount((float) $request->subtotal);

        return response()->json([
            'valid'          => true,
            'coupon_id'      => $coupon->id,
            'discount_type'  => $coupon->discount_type,
            'discount_value' => $coupon->discount_value,
            'discount_amount'=> $discountAmount,
            'label'          => $coupon->discountLabel(),
        ]);
    }

    // ── Bill from Treatment Plan (partial multi-tooth) ───────────────────────
    // Opens a screen listing the plan's items with a checkbox per PENDING tooth.
    // The user ticks only the teeth completed this visit; the rest stay pending
    // on the plan until a later visit.

    public function billFromPlan(TreatmentPlan $plan, TreatmentPlanBillingService $service)
    {
        $plan->load(['patient', 'items.teeth']);

        // Lazily create per-tooth rows the first time this plan is billed.
        $service->ensurePlanTeeth($plan);
        $plan->load('items.teeth');

        // Items that still have at least one pending tooth.
        $billableItems = $plan->items->filter(
            fn ($item) => $item->teeth->where('status', 'pending')->isNotEmpty()
        );

        return view('billing.from-plan', compact('plan', 'billableItems'));
    }

    public function storeFromPlan(Request $request, TreatmentPlan $plan, TreatmentPlanBillingService $service)
    {
        // S1 — an unaccepted plan is a quotation, not work the patient agreed
        // to; invoicing one is a billing error. The mobile read endpoint has
        // always enforced this (Api\V1\TreatmentPlanController::billableTeeth);
        // the web write path did not. Same message, for parity.
        if (is_null($plan->accepted_at)) {
            return back()->withErrors(['tooth_ids' => 'This plan must be accepted before billing.']);
        }

        $request->validate([
            'tooth_ids'   => 'required|array|min:1',
            'tooth_ids.*' => 'integer',
        ]);

        try {
            $invoice = $service->createInvoiceFromSelection(
                $plan,
                array_map('intval', $request->tooth_ids),
                auth()->id(),
            );
        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->withErrors($e->errors());
        }

        return redirect()->route('billing.show', $invoice)
            ->with('success', 'Invoice created from treatment plan. Remaining teeth stay pending.');
    }

    // ── Apply Manual Discount ────────────────────────────────────────────────
    // Header-level doctor/manager discount, separate from coupons. Permission +
    // role limit are enforced inside ManualDiscountService, which also writes the
    // full accountability entry (old total, discount, new total, reason, user).

    public function applyManualDiscount(Request $request, Invoice $invoice)
    {
        $request->validate([
            'manual_discount_type'  => 'required|in:flat,percentage',
            'manual_discount_value' => 'required|numeric|min:0.01',
            'manual_discount_reason'=> 'required|string|min:3|max:500',
        ]);

        try {
            (new \App\Services\Billing\ManualDiscountService())->apply(
                $invoice,
                $request->manual_discount_type,
                (float) $request->manual_discount_value,
                $request->manual_discount_reason,
                auth()->user()
            );
        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }

        return back()->with('success', 'Manual discount applied.');
    }

    // ── Remove Manual Discount ───────────────────────────────────────────────

    public function removeManualDiscount(Request $request, Invoice $invoice)
    {
        try {
            (new \App\Services\Billing\ManualDiscountService())->remove(
                $invoice,
                auth()->user(),
                $request->input('reason', 'Manual discount removed')
            );
        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->withErrors($e->errors());
        }

        return back()->with('success', 'Manual discount removed.');
    }

    // ── Store ────────────────────────────────────────────────────────────────

    public function store(Request $request)
    {
        $request->validate([
            'patient_id'            => 'required|exists:patients,id',
            'invoice_date'          => 'required|date',
            'due_date'              => 'nullable|date|after_or_equal:invoice_date',
            'discount_pct'          => 'nullable|numeric|min:0|max:100',
            'notes'                 => 'nullable|string|max:1000',
            'items'                 => 'required|array|min:1',
            'items.*.description'   => 'required|string|max:200',
            'items.*.unit_price'    => 'required|numeric|min:0',
            'items.*.qty'           => 'required|integer|min:1',
            'items.*.disc_pct'      => 'nullable|numeric|min:0|max:100',
            'items.*.gst_pct'       => 'nullable|numeric|min:0|max:100',
            'items.*.tooth_number'  => 'nullable|string|max:100',
            'items.*.treatment_id'  => 'nullable|integer|exists:treatments,id',
            'items.*.inventory_item_id' => 'nullable|integer|exists:inventory_items,id',
            // Discount layers
            'coupon_code'           => 'nullable|string|max:50',
            'wallet_applied'        => 'nullable|numeric|min:0',
            'wallet_treatment_ids'  => 'nullable|array',       // treatment IDs for promo restriction check
            'wallet_treatment_ids.*'=> 'integer',
            'membership_discount'   => 'nullable|numeric|min:0',
            // Manual discount (permission + limit enforced in ManualDiscountService)
            'manual_discount_type'  => 'nullable|in:flat,percentage',
            'manual_discount_value' => 'nullable|numeric|min:0',
            'manual_discount_reason'=> 'nullable|string|max:500',
            'prompt_ids'            => 'nullable|array',
            'prompt_ids.*'          => 'integer|exists:billing_prompts,id',
        ]);

        $invoiceId = null;

        DB::transaction(function () use ($request, &$invoiceId) {

            // ── Create invoice header ────────────────────────────────────────
            // Discounts (coupon / membership / wallet) are all recomputed
            // server-side AFTER the line items are saved — never trust a
            // client-submitted rupee amount (mirrors Api/V1/BillingController).
            $invoice = Invoice::create([
                'invoice_number'      => Invoice::nextNumber(),
                'patient_id'          => $request->patient_id,
                'invoice_date'        => $request->invoice_date,
                'due_date'            => $request->due_date,
                'discount_pct'        => $request->discount_pct ?? 0,
                'wallet_applied'      => 0,
                'coupon_id'           => null,
                'coupon_discount'     => 0,
                'membership_discount' => 0,
                'notes'               => $request->notes,
                'status'              => 'draft',
                'created_by'          => auth()->id(),
            ]);

            // ── Save line items ──────────────────────────────────────────────
            foreach ($request->items as $i => $row) {
                $item = new InvoiceItem([
                    'invoice_id'         => $invoice->id,
                    'treatment_id'       => $row['treatment_id'] ?? null,   // link to Treatment master
                    'inventory_item_id'  => $row['inventory_item_id'] ?? null, // link to retail product sold
                    'description'        => $row['description'],
                    'tooth_number'       => $row['tooth_number'] ?? null,
                    'unit_price'         => $row['unit_price'],
                    'qty'                => $row['qty'],
                    'disc_pct'           => $row['disc_pct'] ?? 0,
                    'gst_pct'            => $row['gst_pct'] ?? 0,
                    'sort_order'         => $i,
                ]);
                $item->compute();
                $item->save();
            }

            $invoice->recalculate();
            $this->applyRetailStockMovements($invoice);
            $invoiceId = $invoice->id;

            // Additive Activity log (docs/backend-orchestration-plan.md §2.8) —
            // no rule currently matches 'invoice.created', feeds Insights only.
            app(ActivityEngine::class)->log(
                subject:        $invoice,
                event:          'invoice.created',
                actor:          Auth::user(),
                metadata:       ['patient_id' => (int) $request->patient_id],
                relationshipId: Patient::find($request->patient_id)?->relationship_id,
                description:    'Invoice created',
            );

            // ── Coupon (server-side recompute) ───────────────────────────────
            if ($request->filled('coupon_code')) {
                $coupon = CouponCode::active()
                    ->where('code', strtoupper(trim($request->coupon_code)))
                    ->first();
                if (! $coupon) {
                    throw \Illuminate\Validation\ValidationException::withMessages([
                        'coupon_code' => 'Invalid or expired coupon code.',
                    ]);
                }
                if (! $coupon->canBeUsedByPatient((int) $request->patient_id)) {
                    throw \Illuminate\Validation\ValidationException::withMessages([
                        'coupon_code' => 'This coupon has already been used the maximum number of times for this patient.',
                    ]);
                }
                if ((float) $invoice->subtotal < (float) $coupon->min_invoice_amount) {
                    throw \Illuminate\Validation\ValidationException::withMessages([
                        'coupon_code' => 'Minimum invoice amount for this coupon is Rs. ' . number_format((float) $coupon->min_invoice_amount, 0) . '.',
                    ]);
                }

                $couponDiscount = $coupon->calculateDiscount((float) $invoice->subtotal);
                if ($couponDiscount > 0) {
                    $invoice->update(['coupon_id' => $coupon->id, 'coupon_discount' => $couponDiscount]);
                    (new CouponService())->apply(
                        couponId:       $coupon->id,
                        patientId:      (int) $request->patient_id,
                        invoiceId:      $invoice->id,
                        discountAmount: $couponDiscount,
                        createdBy:      auth()->id()
                    );
                }
            }

            // ── Membership discount (server-side recompute) ──────────────────
            // The submitted membership_discount is treated as an opt-in signal
            // only; the rupee amount is always recomputed from the saved items.
            if ((float) $request->input('membership_discount', 0) > 0) {
                $invoice->refresh();
                $eligibleItems = $invoice->items->whereNull('inventory_item_id');
                $lineItems = $eligibleItems->map(fn ($it) => [
                    'name'   => $it->description,
                    'amount' => (float) $it->unit_price,
                    'qty'    => (int) $it->qty,
                ])->all();
                $eligibleSubtotal = (float) $eligibleItems->sum(fn ($it) => (float) $it->unit_price * (int) $it->qty);
                $benefit = MembershipBenefitService::forPatient((int) $request->patient_id, $lineItems, $eligibleSubtotal);
                if (($benefit['active'] ?? false) && ($benefit['discount'] ?? 0) > 0) {
                    $invoice->update([
                        'membership_id'       => $benefit['membership_id'],
                        'membership_discount' => $benefit['discount'],
                    ]);
                }
            }

            $invoice->recalculate();

            // ── Wallet (capped + synced to the amount actually debited) ──────
            // Pass treatment IDs so promo credits can be hard-blocked for
            // non-applicable treatments. WalletService::debit() caps the debit
            // to the real/eligible balance — the invoice must reflect the
            // debited figure, never the requested one.
            if ((float) $request->input('wallet_applied', 0) > 0) {
                $invoice->refresh();
                $wallet    = Wallet::forPatient((int) $request->patient_id);
                $requested = (float) $request->wallet_applied;
                // U8 rule 9 — only CLINIC-FUNDED (promotional) credit may reduce an
                // invoice. Patient credit is a tender and is applied at payment
                // time via WalletService::settleInvoiceFromCredit(), never here.
                $cap       = min($requested, (float) $wallet->balance_promotional, (float) $invoice->balance_due);
                if ($cap > 0) {
                    $debited = (new WalletService())->debit(
                        patientId:    (int) $request->patient_id,
                        amount:       $cap,
                        invoiceId:    $invoice->id,
                        createdBy:    auth()->id(),
                        treatmentIds: array_map('intval', (array) ($request->wallet_treatment_ids ?? []))
                    );
                    if ($debited > 0) {
                        $invoice->update(['wallet_applied' => $debited]);
                    }
                }
                $invoice->recalculate();
            }

            // ── Mark billing prompts as invoiced ─────────────────────────────
            if ($request->filled('prompt_ids')) {
                BillingPrompt::whereIn('id', $request->prompt_ids)
                    ->where('patient_id', $request->patient_id)
                    ->where('status', 'pending')
                    ->each(fn($p) => $p->markInvoiced($invoice, auth()->id()));
            }

            // ── Mark visit items as billed ───────────────────────────────────
            // Link visit items that were included as line items
            if ($request->has('visit_item_ids')) {
                TreatmentVisitItem::whereIn('id', $request->visit_item_ids)
                    ->where('patient_id', $request->patient_id)
                    ->update(['billing_status' => 'invoiced']); // enum: pending | invoiced | waived
            }

            // ── Apply manual discount ────────────────────────────────────────
            // Permission + role limit are enforced inside the service; a failure
            // throws ValidationException which rolls back this whole transaction.
            if ((float) $request->input('manual_discount_value', 0) > 0) {
                (new \App\Services\Billing\ManualDiscountService())->apply(
                    $invoice,
                    $request->input('manual_discount_type', 'flat'),
                    (float) $request->manual_discount_value,
                    (string) $request->input('manual_discount_reason', ''),
                    auth()->user()
                );
            }
        });

        return redirect()->route('billing.show', $invoiceId)
            ->with('success', 'Invoice created successfully.');
    }

    // ── Show ─────────────────────────────────────────────────────────────────

    public function show(Invoice $invoice)
    {
        $invoice->load(['patient', 'items', 'payments', 'receipts', 'finalBill']);
        // Clinic bank accounts for the "Received In" dropdown in the payment form
        $bankAccounts = FinanceBankAccount::where('is_active', true)
            ->orderByDesc('is_primary')
            ->orderBy('account_name')
            ->get(['id', 'account_name', 'bank_name', 'account_type']);
        // Wallet — powers the "Use wallet credit" allocation in the payment modal
        $wallet = Wallet::forPatient($invoice->patient_id);
        $wallet->recalculate();
        return view('billing.show', compact('invoice', 'bankAccounts', 'wallet'));
    }

    // ── Edit ─────────────────────────────────────────────────────────────────

    public function edit(Invoice $invoice)
    {
        if (in_array($invoice->status, ['paid', 'cancelled'])) {
            return redirect()->route('billing.show', $invoice)
                ->with('error', 'Paid or cancelled invoices cannot be edited.');
        }

        $invoice->load('items');
        $patients        = Patient::orderBy('name')->get(['id', 'name', 'phone']);
        $treatments      = Treatment::where('is_active', true)->orderBy('name')->get(['id', 'name', 'default_price', 'gst_pct', 'unit_basis']);
        // withSum so the picker can warn/block on out-of-stock items client-side
        // rather than silently letting stock go negative at invoice save time.
        $sellableProducts = InventoryItem::sellable()->orderBy('product_name')
            ->withSum('stocks', 'available_qty')
            ->get(['id', 'product_name', 'mrp', 'gst_rate']);
        $selectedPatient = $invoice->patient;

        return view('billing.form', compact('invoice', 'patients', 'treatments', 'sellableProducts', 'selectedPatient'));
    }

    // ── Update ───────────────────────────────────────────────────────────────

    public function update(Request $request, Invoice $invoice)
    {
        if (in_array($invoice->status, ['paid', 'cancelled'])) {
            return back()->with('error', 'Paid or cancelled invoices cannot be edited.');
        }

        $request->validate([
            'patient_id'          => 'required|exists:patients,id',
            'invoice_date'        => 'required|date',
            'due_date'            => 'nullable|date|after_or_equal:invoice_date',
            'discount_pct'        => 'nullable|numeric|min:0|max:100',
            'notes'               => 'nullable|string|max:1000',
            'items'               => 'required|array|min:1',
            'items.*.description' => 'required|string|max:200',
            'items.*.unit_price'  => 'required|numeric|min:0',
            'items.*.qty'         => 'required|integer|min:1',
            'items.*.disc_pct'    => 'nullable|numeric|min:0|max:100',
            'items.*.gst_pct'     => 'nullable|numeric|min:0|max:100',
            'items.*.tooth_number'=> 'nullable|string|max:100',
            'items.*.treatment_id'=> 'nullable|integer|exists:treatments,id',
            'items.*.inventory_item_id' => 'nullable|integer|exists:inventory_items,id',
            'manual_discount_type'  => 'nullable|in:flat,percentage',
            'manual_discount_value' => 'nullable|numeric|min:0',
            'manual_discount_reason'=> 'nullable|string|max:500',
        ]);

        // Optimistic lock — this update wholesale deletes and recreates the line
        // items, so a stale save would silently destroy edits (and stock
        // movements) another user made in the meantime.
        $this->assertNotStale($request, $invoice);

        DB::transaction(function () use ($request, $invoice) {
            $invoice->update([
                'patient_id'   => $request->patient_id,
                'invoice_date' => $request->invoice_date,
                'due_date'     => $request->due_date,
                'discount_pct' => $request->discount_pct ?? 0,
                'notes'        => $request->notes,
                'updated_by'   => auth()->id(),
            ]);

            // Invoice items are wholesale deleted + recreated below (not diffed),
            // so reverse whatever this invoice previously deducted from stock
            // before recreating the lines, then re-deduct fresh for the new set.
            $this->reverseRetailStockMovements($invoice);

            // S1 — the lines about to be destroyed may be holding treatment-plan
            // teeth on 'invoiced'. The FK nulls invoice_item_id on delete but
            // leaves the status, so without this release the teeth claimed to be
            // invoiced with no invoice at all. Release them BEFORE the delete,
            // while the linkage still exists.
            app(PlanBillingRollbackService::class)->rollbackInvoiceItems($invoice->items()->get());

            $invoice->items()->delete();

            foreach ($request->items as $i => $row) {
                $item = new InvoiceItem([
                    'invoice_id'        => $invoice->id,
                    'treatment_id'      => $row['treatment_id'] ?? null,   // link to Treatment master
                    'inventory_item_id' => $row['inventory_item_id'] ?? null, // link to retail product sold
                    'description'       => $row['description'],
                    'tooth_number'      => $row['tooth_number'] ?? null,
                    'unit_price'        => $row['unit_price'],
                    'qty'               => $row['qty'],
                    'disc_pct'          => $row['disc_pct'] ?? 0,
                    'gst_pct'           => $row['gst_pct'] ?? 0,
                    'sort_order'        => $i,
                ]);
                $item->compute();
                $item->save();
            }

            $invoice->recalculate();
            $invoice->refresh();
            $this->applyRetailStockMovements($invoice);

            // Manual discount: apply if provided, otherwise clear any existing one.
            $mdVal = (float) $request->input('manual_discount_value', 0);
            $mdService = new \App\Services\Billing\ManualDiscountService();
            if ($mdVal > 0) {
                $mdService->apply(
                    $invoice,
                    $request->input('manual_discount_type', 'flat'),
                    $mdVal,
                    (string) $request->input('manual_discount_reason', ''),
                    auth()->user()
                );
            } elseif (($invoice->manual_discount_amount ?? 0) > 0) {
                $mdService->remove($invoice, auth()->user(), 'Cleared during invoice edit');
            }
        });

        return redirect()->route('billing.show', $invoice)
            ->with('success', 'Invoice updated successfully.');
    }

    // ── Retail stock sync ────────────────────────────────────────────────────
    // A patient invoice can carry retail product lines (toothpaste, brushes,
    // OTC medicines — is_sellable items). Selling one auto-deducts stock the
    // same way TreatmentVisitService already does for implants: a StockMovement
    // row, not a direct decrement, so the change is auditable and feeds the
    // existing low-stock alerts automatically.

    /**
     * Deduct stock for every sellable-product line currently on this invoice.
     * Call after items are (re)created. Safe to call on an invoice with no
     * product lines — it simply does nothing.
     */
    private function applyRetailStockMovements(Invoice $invoice): void
    {
        $lines = $invoice->items()->whereNotNull('inventory_item_id')->get();
        if ($lines->isEmpty()) {
            return;
        }

        $location = InventoryLocation::where('type', 'main_store')->where('is_active', true)->first()
            ?? InventoryLocation::where('is_active', true)->first();
        if (!$location) {
            return; // no location configured yet — never block the billing save on this
        }

        foreach ($lines as $line) {
            $item = InventoryItem::find($line->inventory_item_id);
            if (!$item || !$item->is_sellable) {
                continue; // item was deleted or un-marked sellable since the line was added
            }

            StockMovement::create([
                'inventory_item_id' => $item->id,
                'movement_type'     => 'retail_sale',
                'qty'               => -$line->qty,
                'from_location_id'  => $location->id,
                'unit_cost'         => $item->average_purchase_price,
                'total_cost'        => round($item->average_purchase_price * $line->qty, 2),
                'reference_type'    => Invoice::class,
                'reference_id'      => $invoice->id,
                'notes'             => 'Retail sale — invoice ' . $invoice->invoice_number,
                'created_by'        => auth()->id(),
            ]);
        }
    }

    /**
     * Reverse every retail-sale deduction previously recorded against this
     * invoice, by creating compensating stock-in entries (never deleting the
     * original movement rows — the ledger stays a full audit trail of "sold,
     * then reversed" rather than pretending the sale never happened).
     * Call before invoice_items are deleted/recreated on edit, and before an
     * invoice is cancelled/deleted.
     */
    private function reverseRetailStockMovements(Invoice $invoice): void
    {
        $priorSales = StockMovement::where('reference_type', Invoice::class)
            ->where('reference_id', $invoice->id)
            ->where('movement_type', 'retail_sale')
            ->get();

        foreach ($priorSales as $movement) {
            StockMovement::create([
                'inventory_item_id' => $movement->inventory_item_id,
                'movement_type'     => 'stock_in',
                'qty'               => abs($movement->qty),
                'to_location_id'    => $movement->from_location_id,
                'unit_cost'         => $movement->unit_cost,
                'total_cost'        => $movement->total_cost,
                'reference_type'    => Invoice::class,
                'reference_id'      => $invoice->id,
                'notes'             => 'Reversal — invoice ' . $invoice->invoice_number . ' edited/cancelled',
                'created_by'        => auth()->id(),
            ]);
        }
    }

    // ── Reverse wallet credit debited against this invoice ──────────────────
    // If wallet balance was applied when this invoice was created, deleting or
    // cancelling it must give that credit back — otherwise the debit stays on
    // the wallet ledger forever with no invoice to show what it paid for, and
    // the patient's usable balance is short by that amount permanently.
    private function reverseInvoiceWalletDebit(Invoice $invoice, string $reason): void
    {
        // Shared brain — same reversal the API cancel path uses.
        (new WalletService())->reverseInvoiceDebit($invoice, $reason, auth()->id());
    }

    // ── Destroy ──────────────────────────────────────────────────────────────
    // Called from the 3-dot menu on Finance > Invoices tab.
    // Unpaid/draft invoices: simple soft-delete with reason.
    // Paid/partial invoices: must go through cancelInvoice() which handles refunds.

    public function destroy(Request $request, Invoice $invoice)
    {
        if (! auth()->user()->isAdminRole()) {
            abort(403, 'Only admins can delete invoices.');
        }

        // Paid or partial invoices have money attached — use cancelInvoice flow
        if (in_array($invoice->status, ['paid', 'partial'])) {
            return $this->cancelInvoice($request, $invoice);
        }

        // Unpaid / draft — just needs a reason
        $request->validate([
            'cancelled_reason' => 'required|string|min:5|max:500',
        ]);

        BillingAuditLog::record(
            'delete_invoice',
            $invoice,
            $request->cancelled_reason,
            auth()->id(),
            $invoice->invoice_number
        );

        $this->reverseRetailStockMovements($invoice);
        $this->reverseInvoiceWalletDebit($invoice, 'invoice ' . $invoice->invoice_number . ' deleted. ' . $request->cancelled_reason);

        // S1 — release any treatment-plan teeth this invoice billed, so the
        // clinic can re-invoice them. Without this they stayed 'invoiced'
        // against a deleted invoice and were unbillable forever.
        app(PlanBillingRollbackService::class)->rollbackInvoice($invoice);

        $invoice->update([
            'status'           => 'cancelled',
            'cancelled_reason' => $request->cancelled_reason,
            'cancelled_by'     => auth()->id(),
        ]);
        $invoice->delete();

        return redirect()->route('finance.income')->with('success', 'Invoice ' . $invoice->invoice_number . ' deleted.');
    }

    // ── Cancel (legacy — kept for backward compat with existing patient profile button) ──

    public function cancel(Invoice $invoice)
    {
        $this->reverseRetailStockMovements($invoice);
        // S1 — same plan-teeth release as every other cancel path.
        app(PlanBillingRollbackService::class)->rollbackInvoice($invoice);
        $invoice->update(['status' => 'cancelled']);
        return back()->with('success', 'Invoice cancelled.');
    }

    // ── Record Payment ───────────────────────────────────────────────────────
    // Saves payment → auto-creates Receipt → auto-generates FinalBill if fully paid.
    // Handles mode-specific rules: CC convenience fee, cheque fields, EMI schedule.

    public function recordPayment(Request $request, Invoice $invoice)
    {
        if ($invoice->status === 'cancelled') {
            return back()->with('error', 'Cannot record payment on a cancelled invoice.');
        }

        $mode    = $request->input('payment_mode');
        $emiType = $request->input('emi_type', 'direct'); // 'direct' or 'provider'

        // ── Validation (base + mode-specific) ───────────────────────────────
        $rules = [
            // U8 rule 10 — a 100% patient-credit settlement is valid, so the
            // cash leg may legitimately be 0. The combined tender total is
            // validated after this rule set (see the check below).
            'amount'            => 'required|numeric|min:0',
            'payment_mode'      => 'required|in:cash,card,debit_card,upi,cheque,netbanking,bank_transfer,emi,other',
            'payment_date'      => 'required|date',
            'clinic_account_id' => 'nullable|exists:finance_bank_accounts,id',
            'reference_no'      => 'nullable|string|max:100',
            'notes'             => 'nullable|string|max:500',
            // Payment allocation: draw part of the payment from wallet credit
            'wallet_used'       => 'nullable|numeric|min:0',
        ];

        // UPI / netbanking / bank_transfer — reference required
        if (in_array($mode, ['upi', 'netbanking', 'bank_transfer'])) {
            $rules['reference_no'] = 'required|string|max:100';
        }

        // Cheque — extra fields required
        if ($mode === 'cheque') {
            $rules['bank_name']   = 'required|string|max:100';
            $rules['cheque_no']   = 'required|string|max:50';
            $rules['cheque_date'] = 'required|date';
        }

        // Credit card — convenience fee field
        if ($mode === 'card') {
            $rules['convenience_fee'] = 'nullable|numeric|min:0';
        }

        // EMI — sub-type specific validation
        if ($mode === 'emi') {
            $rules['emi_type'] = 'required|in:direct,provider';

            if ($emiType === 'direct') {
                // Direct EMI: clinic collects instalments
                $rules['emi_provider']      = 'nullable|string|max:100';
                $rules['emi_tenure']        = 'required|integer|min:1|max:84';
                $rules['emi_interest_rate'] = 'required|numeric|min:0|max:36';
                $rules['emi_start_date']    = 'required|date|after_or_equal:today';
            } else {
                // Provider EMI: provider pays clinic upfront
                $rules['emi_provider_scheme_id'] = 'required|integer|exists:emi_schemes,id';
                $rules['emi_upfront_amount']     = 'nullable|numeric|min:0';
                $rules['convenience_fee']        = 'nullable|numeric|min:0';
            }
        }

        $request->validate($rules);

        // U8 rule 10 — something must actually be tendered. Cash may be 0 only
        // when patient credit is covering the settlement.
        if ((float) $request->input('amount', 0) + (float) $request->input('wallet_used', 0) < 0.01) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'amount' => 'Enter an amount, or apply patient credit.',
            ]);
        }

        // ── Credit Card: convenience fee (configurable in Settings → Billing) ─
        // Fee applies per-transaction: when THIS payment amount exceeds the
        // threshold, add (rate %) of the amount. Threshold & rate come from
        // AppSetting (billing group), defaulting to ₹10,000 and 2.5%.
        $convenienceFee = 0;
        if ($mode === 'card') {
            $threshold = (float) \App\Models\AppSetting::get('cc_convenience_threshold', 10000);
            $rate      = (float) \App\Models\AppSetting::get('cc_convenience_rate', 2.5);
            $amount    = (float) $request->amount;

            if ($amount > $threshold) {
                $convenienceFee = round($amount * $rate / 100, 2);
            }

            // Server value is authoritative; never trust a lower submitted value
            $submitted      = (float) ($request->convenience_fee ?? 0);
            $convenienceFee = max($convenienceFee, $submitted);
        }

        // ── Provider EMI: load scheme & compute breakdown ────────────────────
        $providerScheme    = null;
        $providerBreakdown = null;
        if ($mode === 'emi' && $emiType === 'provider') {
            $providerScheme    = EmiScheme::findOrFail($request->emi_provider_scheme_id);
            $invoiceTotal      = (float) $invoice->total_amount;
            $providerBreakdown = $providerScheme->breakdown($invoiceTotal);

            // Convenience fee from scheme (override if submitted value differs)
            if ($providerScheme->pass_cost_to_patient) {
                $convenienceFee = $providerBreakdown['convenience_charge'];
            }
        }

        $receipt = null;
        $walletReceipt     = null; // U8: receipt for the patient-credit tender leg
        $walletUsedApplied = 0.0; // how much patient credit was tendered in this payment
        $excessToWallet    = 0.0; // overpayment moved into patient credit

        DB::transaction(function () use (
            $request, $invoice, $mode, $emiType,
            $convenienceFee, $providerScheme, $providerBreakdown,
            &$receipt, &$walletReceipt, &$walletUsedApplied, &$excessToWallet
        ) {
            // ── Concurrency guard ────────────────────────────────────────────
            // Lock the invoice row so concurrent submissions serialize, then
            // re-check state on fresh data and reject an identical resubmission
            // (double-click / network replay) within a short window.
            Invoice::whereKey($invoice->id)->lockForUpdate()->firstOrFail();
            $invoice->refresh();

            if ($invoice->status === 'cancelled') {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'amount' => 'Cannot record payment on a cancelled invoice.',
                ]);
            }

            $isDuplicate = InvoicePayment::where('invoice_id', $invoice->id)
                ->where('amount', (float) $request->amount)
                ->where('payment_mode', $mode)
                ->whereDate('payment_date', $request->payment_date)
                ->where('created_at', '>=', now()->subSeconds(20))
                ->exists();
            if ($isDuplicate) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'amount' => 'An identical payment was recorded seconds ago — this looks like a duplicate submission. Refresh the page to verify before retrying.',
                ]);
            }

            $paidBefore = (float) $invoice->paid_amount;

            // ── U8 — Patient Credit is a PAYMENT TENDER, not a discount ─────
            // Rule 8: it settles the invoice exactly like cash. Rule 9: it must
            // NEVER reduce the invoice total. settleInvoiceFromCredit() creates a
            // real InvoicePayment (payment_mode='wallet'), its own receipt and an
            // income FinanceTransaction, and leaves invoices.wallet_applied alone.
            $walletRequested = (float) $request->input('wallet_used', 0);
            if ($walletRequested > 0) {
                $walletResult = (new WalletService())->settleInvoiceFromCredit(
                    invoice:     $invoice,
                    amount:      $walletRequested,
                    createdBy:   auth()->id(),
                    paymentDate: $request->payment_date,
                    notes:       'Paid from patient credit',
                );

                if ($walletResult['debited'] > 0) {
                    $walletUsedApplied = $walletResult['debited'];
                    $walletReceipt     = $walletResult['receipt'];
                    $invoice->refresh();
                }
            }

            // ── G1 — split the cash tender: settlement vs advance ────────────
            // Only the part that actually settles THIS invoice is revenue. Any
            // surplus is money received against no service — U8 rule 2 says that
            // is a liability, not income. Previously the whole tender was booked
            // as income and the surplus was ALSO turned into patient credit, so
            // the same rupees were revenue and a liability at once.
            //
            // When the payment does not exceed the balance (the overwhelmingly
            // normal case) $settlementAmount === $request->amount and every
            // record below is byte-identical to before. This only activates on a
            // genuine overpayment.
            $cashTendered     = (float) $request->amount;
            $settlementAmount = round(min($cashTendered, (float) $invoice->balance_due), 2);
            $excessToWallet   = round($cashTendered - $settlementAmount, 2);
            if ($excessToWallet < 0.01) {
                $excessToWallet   = 0.0;
                $settlementAmount = $cashTendered;
            }

            // U8 rule 10 — 100% patient-credit settlement. The wallet tender
            // above already produced the payment, the receipt and the finance
            // entry, so there is no cash leg to record. Returning here exits the
            // transaction closure; the transaction still commits normally.
            if ($settlementAmount <= 0) {
                // Nothing left to settle on this invoice. Anything tendered is
                // purely an advance — book it through the U8 advance path so it
                // lands as a liability with its own ADV- receipt, never income.
                if ($excessToWallet > 0) {
                    (new WalletService())->receiveAdvance(
                        patient:     Patient::findOrFail($invoice->patient_id),
                        amount:      $excessToWallet,
                        paymentMode: $mode,
                        paymentDate: $request->payment_date,
                        notes:       'Excess payment from ' . $invoice->invoice_number,
                        createdBy:   auth()->id(),
                    );
                }

                $receipt = $walletReceipt;

                $invoice->refresh();
                if ($invoice->isFullyPaid() && !$invoice->hasFinalBill()) {
                    FinalBill::generateFromInvoice($invoice, auth()->id());
                }

                return;
            }

            // ── Direct EMI: compute instalment amount ────────────────────────
            $emiAmount = null;
            if ($mode === 'emi' && $emiType === 'direct' && $request->emi_tenure > 0) {
                $schedule  = EmiSchedule::buildSchedule(
                    $settlementAmount,
                    (float) $request->emi_interest_rate,
                    (int)   $request->emi_tenure,
                    $request->emi_start_date
                );
                $emiAmount = $schedule[0]['emi_amount'] ?? null;
            }

            // ── Provider EMI: derive stored values ───────────────────────────
            $clinicNetAmount  = null;
            $emiUpfrontAmount = null;
            if ($mode === 'emi' && $emiType === 'provider' && $providerBreakdown) {
                $clinicNetAmount  = $providerBreakdown['clinic_net_amount'];
                $emiUpfrontAmount = $request->emi_upfront_amount ?? $providerBreakdown['patient_upfront_amount'];
            }

            // 1. Save payment record
            // Resolve clinic account name for display caching
            $clinicAccountName = null;
            if ($request->filled('clinic_account_id')) {
                $clinicAccountName = FinanceBankAccount::find($request->clinic_account_id)?->account_name;
            }

            $payment = InvoicePayment::create([
                'invoice_id'             => $invoice->id,
                'patient_id'             => $invoice->patient_id,
                'amount'                 => $settlementAmount,
                'payment_mode'           => $mode,
                'payment_date'           => $request->payment_date,
                'reference_no'           => $request->reference_no,
                'notes'                  => $request->notes,
                'created_by'             => auth()->id(),
                // Clinic account received in (Phase 2)
                'clinic_account_id'      => $request->clinic_account_id ?: null,
                'clinic_account_name'    => $clinicAccountName,
                // Cheque
                'bank_name'              => $request->bank_name,
                'cheque_no'              => $request->cheque_no,
                'cheque_date'            => $request->cheque_date,
                'cheque_status'          => $mode === 'cheque' ? 'pending' : null,
                // Credit card / Provider EMI convenience
                'convenience_fee'        => $convenienceFee,
                // Direct EMI fields
                'emi_type'               => $mode === 'emi' ? $emiType : null,
                'emi_provider'           => $mode === 'emi' && $emiType === 'direct' ? $request->emi_provider : null,
                'emi_tenure'             => $mode === 'emi' && $emiType === 'direct' ? $request->emi_tenure : ($providerScheme?->tenure_months),
                'emi_interest_rate'      => $mode === 'emi' && $emiType === 'direct' ? $request->emi_interest_rate : null,
                'emi_amount'             => $emiAmount ?? ($providerBreakdown ? $providerBreakdown['patient_monthly_emi'] : null),
                'emi_start_date'         => $mode === 'emi' && $emiType === 'direct' ? $request->emi_start_date : now()->toDateString(),
                // Provider EMI fields
                'emi_provider_scheme_id' => $providerScheme?->id,
                'emi_upfront_amount'     => $emiUpfrontAmount,
                'clinic_net_amount'      => $clinicNetAmount,
            ]);

            // 2. Generate instalment schedule (Direct EMI only)
            // Provider EMI: provider handles collection — no schedule needed here
            if ($mode === 'emi' && $emiType === 'direct' && $request->emi_tenure > 0) {
                $schedule = EmiSchedule::buildSchedule(
                    $settlementAmount,
                    (float) $request->emi_interest_rate,
                    (int)   $request->emi_tenure,
                    $request->emi_start_date
                );
                foreach ($schedule as $row) {
                    EmiSchedule::create([
                        'invoice_payment_id' => $payment->id,
                        'invoice_id'         => $invoice->id,
                        'patient_id'         => $invoice->patient_id,
                        'instalment_no'      => $row['instalment_no'],
                        'due_date'           => $row['due_date'],
                        'principal'          => $row['principal'],
                        'interest'           => $row['interest'],
                        'emi_amount'         => $row['emi_amount'],
                        'status'             => 'pending',
                        'created_by'         => auth()->id(),
                    ]);
                }
            }

            // 3. Recalculate invoice totals
            $invoice->recalculate();
            $invoice->refresh();
            $balanceAfter = (float) $invoice->balance_due;

            // 3b. G1 — the surplus is an ADVANCE, not revenue.
            // Routed through the same U8 path an over-the-counter advance uses:
            // patient credit + its own ADV- receipt + FinanceTransaction
            // type='advance'. The income entry below covers only the settlement,
            // so the same rupee is never both revenue and a liability.
            if ($excessToWallet > 0) {
                (new WalletService())->receiveAdvance(
                    patient:     Patient::findOrFail($invoice->patient_id),
                    amount:      $excessToWallet,
                    paymentMode: $mode,
                    paymentDate: $request->payment_date,
                    notes:       'Excess payment from ' . $invoice->invoice_number,
                    createdBy:   auth()->id(),
                );
            }

            // 4. Generate receipt(s)
            //
            // Provider EMI — split receipt model:
            //   Receipt #1 (now)  → patient upfront amount only (emi_upfront_amount)
            //   Receipt #2 (later)→ clinic_net_amount, created by markProviderPaid()
            //
            // All other modes → single receipt for the full payment amount.

            if ($mode === 'emi' && $emiType === 'provider') {
                // Only issue Receipt #1 if the patient actually pays something upfront today.
                if ($emiUpfrontAmount > 0) {
                    $receipt = Receipt::create([
                        'receipt_number'     => Receipt::nextNumber(),
                        'invoice_id'         => $invoice->id,
                        'invoice_payment_id' => $payment->id,
                        'patient_id'         => $invoice->patient_id,
                        'amount'             => $emiUpfrontAmount,
                        'payment_mode'       => $mode,
                        'receipt_date'       => $request->payment_date,
                        'reference_no'       => $request->reference_no,
                        'invoice_total'      => $invoice->total_amount,
                        'amount_paid_before' => $paidBefore,
                        'balance_after'      => $balanceAfter,
                        'notes'              => $request->notes,
                        'created_by'         => auth()->id(),
                        'receipt_type'       => 'patient_upfront',
                    ]);
                }
                // Receipt #2 (provider_settlement) is created later via markProviderPaid().
            } else {
                // Standard single-receipt flow for cash / card / UPI / cheque / direct EMI.
                $receipt = Receipt::create([
                    'receipt_number'     => Receipt::nextNumber(),
                    'invoice_id'         => $invoice->id,
                    'invoice_payment_id' => $payment->id,
                    'patient_id'         => $invoice->patient_id,
                    'amount'             => $settlementAmount,
                    'payment_mode'       => $mode,
                    'receipt_date'       => $request->payment_date,
                    'reference_no'       => $request->reference_no,
                    'invoice_total'      => $invoice->total_amount,
                    'amount_paid_before' => $paidBefore,
                    'balance_after'      => $balanceAfter,
                    'notes'              => $request->notes,
                    'created_by'         => auth()->id(),
                ]);
            }

            // 6. Auto-generate FinalBill when fully paid
            if ($invoice->isFullyPaid() && !$invoice->hasFinalBill()) {
                FinalBill::generateFromInvoice($invoice, auth()->id());
            }

            // 7. Finance Mirror
            // For Provider EMI, net_amount reflects what clinic actually receives
            $financeNetAmount = ($mode === 'emi' && $emiType === 'provider' && $clinicNetAmount !== null)
                ? $clinicNetAmount
                : $settlementAmount;

            FinanceTransaction::create([
                'type'              => 'income',
                'direction'         => 'credit',
                'source_type'       => InvoicePayment::class,
                'source_id'         => $payment->id,
                'amount'            => $settlementAmount,
                'net_amount'        => $financeNetAmount,
                'payment_mode'      => $mode,
                'payment_reference' => $request->reference_no,
                'patient_id'        => $invoice->patient_id,
                'status'            => 'active',
                'transaction_date'  => $request->payment_date,
                'notes'             => $request->notes,
                'created_by'        => auth()->id(),
            ]);

            // Additive Activity log (docs/backend-orchestration-plan.md §2.9) —
            // no rule currently matches 'payment.received', feeds Insights only.
            // This web path does NOT call InvoicePaymentService (it has its own
            // wallet-allocation logic the shared service lacks — see the note
            // on the held-back "dedupe" slice), so the log call is duplicated
            // here rather than merged, to avoid touching this live billing flow.
            app(ActivityEngine::class)->log(
                subject:        $payment,
                event:          'payment.received',
                actor:          Auth::user(),
                metadata:       ['patient_id' => $invoice->patient_id, 'invoice_id' => $invoice->id, 'amount' => $settlementAmount],
                relationshipId: Patient::find($invoice->patient_id)?->relationship_id,
                description:    'Payment recorded on invoice ' . $invoice->invoice_number,
            );
        });

        // Build flash message
        if ($mode === 'emi' && $emiType === 'provider' && $providerBreakdown) {
            $upfrontFmt = number_format($providerBreakdown['patient_upfront_amount'], 2);
            $netFmt     = number_format($providerBreakdown['clinic_net_amount'], 2);

            if ($receipt) {
                $msg = 'Provider EMI recorded. Upfront receipt ' . $receipt->receipt_number . ' (₹' . $upfrontFmt . ') generated.';
            } else {
                $msg = 'Provider EMI recorded — no upfront payment (0 upfront EMIs).';
            }
            $msg .= ' Clinic net: ₹' . $netFmt . '. Mark provider payment received to generate settlement receipt.';
            if ($convenienceFee > 0) {
                $msg .= ' Convenience charge ₹' . number_format($convenienceFee, 2) . ' included in patient loan.';
            }
        } else {
            if ((float) $request->amount > 0) {
                $msg = '₹' . number_format($request->amount, 2) . ' recorded. Receipt ' . $receipt->receipt_number . ' generated.';
                if ($convenienceFee > 0) {
                    $msg .= ' Convenience fee ₹' . number_format($convenienceFee, 2) . ' applied.';
                }
            } else {
                // U8 — settled entirely from patient credit; no cash leg exists.
                $msg = 'Settled from patient credit. Receipt '
                     . ($receipt?->receipt_number ?? '—') . ' generated.';
            }
        }

        if ($walletUsedApplied > 0 && (float) $request->amount > 0) {
            $msg .= ' ₹' . number_format($walletUsedApplied, 2) . ' paid from patient credit.';
        }
        if ($excessToWallet > 0) {
            $msg .= ' ₹' . number_format($excessToWallet, 2) . ' excess held as patient credit (not revenue).';
        }

        $invoice->refresh();
        if ($invoice->isFullyPaid()) {
            $msg .= ' Invoice fully paid — Final Bill generated.';
        }

        $fromPatient = $request->input('from_patient');
        $redirectUrl = route('billing.show', $invoice) . ($fromPatient ? '?from_patient=' . $fromPatient : '');

        return redirect($redirectUrl)->with('success', $msg);
    }

    // ── Mark Provider EMI Payment Received ──────────────────────────────────
    // Called when the clinic physically receives the money from the EMI provider.
    // Generates Receipt #2 (provider_settlement) for the clinic_net_amount.

    public function markProviderPaid(Request $request, Invoice $invoice, InvoicePayment $payment)
    {
        // Guard: must be a provider EMI payment that hasn't been marked yet
        if ($payment->emi_type !== 'provider') {
            return back()->with('error', 'This is not a Provider EMI payment.');
        }

        if ($payment->provider_paid_at !== null) {
            return back()->with('error', 'Provider payment has already been marked as received.');
        }

        if ($payment->invoice_id !== $invoice->id) {
            abort(403, 'Payment does not belong to this invoice.');
        }

        $request->validate([
            'provider_paid_date' => 'required|date',
            'provider_reference' => 'nullable|string|max:100',
        ]);

        DB::transaction(function () use ($request, $invoice, $payment) {
            // Generate Receipt #2 — settlement from provider to clinic
            Receipt::create([
                'receipt_number'     => Receipt::nextNumber(),
                'invoice_id'         => $invoice->id,
                'invoice_payment_id' => $payment->id,
                'patient_id'         => $invoice->patient_id,
                'amount'             => $payment->clinic_net_amount,
                'payment_mode'       => 'emi',
                'receipt_date'       => $request->provider_paid_date,
                'reference_no'       => $request->provider_reference,
                'invoice_total'      => $invoice->total_amount,
                'amount_paid_before' => (float) $invoice->paid_amount,
                'balance_after'      => (float) $invoice->balance_due,
                'notes'              => 'Provider EMI settlement receipt.',
                'created_by'         => auth()->id(),
                'receipt_type'       => 'provider_settlement',
            ]);

            // Stamp the payment so we know provider has paid
            $payment->update(['provider_paid_at' => now()]);
        });

        return back()->with('success', 'Provider payment marked as received. Settlement receipt generated for ₹' . number_format($payment->clinic_net_amount, 2) . '.');
    }

    // ── Edit Payment Date ────────────────────────────────────────────────────
    // Corrects the date on an already-recorded payment. Previously there was no
    // edit path at all for a saved payment/receipt — this was raised as a bug
    // ("receipt dates can't be edited"). Cascades to the linked Receipt and
    // FinanceTransaction so payment date, receipt date, and the finance ledger
    // never disagree.

    public function updatePayment(Request $request, Invoice $invoice, InvoicePayment $payment, \App\Services\Billing\InvoicePaymentService $service)
    {
        if ($payment->invoice_id !== $invoice->id) {
            abort(403, 'Payment does not belong to this invoice.');
        }

        if ($invoice->status === 'cancelled') {
            return back()->with('error', 'Cannot edit a payment on a cancelled invoice.');
        }

        $request->validate([
            'payment_date' => ['required', 'date', 'before_or_equal:today'],
        ]);

        $service->updatePaymentDate($payment, $request->input('payment_date'), Auth::id());

        return back()->with('success', 'Payment date updated.');
    }

    // ── Refund charge rate by payment mode ───────────────────────────────────
    // Only card / debit_card attract a 2.5% processing charge on bank transfer.
    // UPI, cash, cheque, netbanking, EMI, and others have no charge.

    private function refundChargeRate(string $paymentMode): float
    {
        return match ($paymentMode) {
            'card', 'debit_card' => 2.5,
            default              => 0.0,
        };
    }

    // ── Void Receipt ─────────────────────────────────────────────────────────
    // Soft-deletes the Receipt + its InvoicePayment. Recalculates invoice totals.
    // Saves void reason + who + refund method to invoice_payments for full audit.
    // If invoice is no longer fully paid after void → auto-deletes linked FinalBill.

    public function voidReceipt(Request $request, Invoice $invoice, Receipt $receipt)
    {
        if ($receipt->invoice_id !== $invoice->id) {
            abort(403, 'Receipt does not belong to this invoice.');
        }

        // Admin-only gate
        if (! auth()->user()->isAdminRole()) {
            abort(403, 'Only admins can void receipts.');
        }

        $request->validate([
            'void_reason'         => 'required|string|min:5|max:500',
            'void_refund_method'  => 'required|in:wallet,cash,bank_transfer,no_refund',
        ]);

        $CARD_CHARGE_PCT = 2.5; // % deducted by clinic for card/UPI reversals

        DB::transaction(function () use ($request, $invoice, $receipt, $CARD_CHARGE_PCT) {
            $amount    = (float) $receipt->amount;
            $patientId = $invoice->patient_id;
            $method    = $request->void_refund_method;

            // Calculate charge: only card/debit_card bank transfers attract 2.5%
            // UPI, cash, cheque, netbanking, EMI → 0% charge
            $chargeRate     = ($method === 'bank_transfer') ? $this->refundChargeRate($receipt->payment_mode) : 0.0;
            $chargeDeducted = round($amount * $chargeRate / 100, 2);
            $refundAmount   = $amount - $chargeDeducted;

            // 1. Audit log
            BillingAuditLog::record(
                'void_receipt',
                $receipt,
                $request->void_reason . ' [refund: ' . $method . ']',
                auth()->id(),
                $receipt->receipt_number
            );

            // 2. Save audit fields + soft-delete the InvoicePayment
            if ($receipt->invoice_payment_id) {
                $payment = InvoicePayment::find($receipt->invoice_payment_id);
                if ($payment) {
                    // Save void audit before deleting
                    $payment->update([
                        'void_reason'          => $request->void_reason,
                        'voided_by'            => auth()->id(),
                        'void_refund_method'   => $method,
                        'void_refund_amount'   => $refundAmount,
                        'void_charge_deducted' => $chargeDeducted,
                    ]);

                    // Reverse the FinanceTransaction for this payment
                    FinanceTransaction::where('source_type', InvoicePayment::class)
                        ->where('source_id', $payment->id)
                        ->where('status', 'active')
                        ->update(['status' => 'voided']);

                    $payment->delete(); // soft-delete
                }
            }

            // 3. Soft-delete the Receipt
            $receipt->delete();

            // 4. Recalculate invoice (paid_amount, balance_due, status)
            $invoice->refresh();
            $invoice->recalculate();

            // 5. Auto-delete Final Bill if invoice is no longer fully paid
            //    (A Final Bill only exists when invoice was 100% paid — now it's invalid)
            $invoice->refresh();
            if ($invoice->status !== 'paid' && $invoice->finalBill) {
                $invoice->finalBill->update([
                    'deleted_reason' => 'Auto-invalidated: linked receipt ' . $receipt->receipt_number . ' was voided. Reason: ' . $request->void_reason,
                    'deleted_by'     => auth()->id(),
                ]);
                $invoice->finalBill->delete();
            }

            // 6. Handle refund / wallet credit / no refund
            $notes = 'Voided receipt ' . $receipt->receipt_number . '. Reason: ' . $request->void_reason;

            // U8 — a wallet-tender leg is the patient's OWN credit. Reversing it
            // must return that credit, regardless of the refund method chosen:
            // the clinic never received cash for this leg, so it cannot pay cash
            // out for it. Rules 8 + 11 + 15.
            if ($receipt->payment_mode === 'wallet') {
                (new WalletService())->restorePatientCredit(
                    patientId: $patientId,
                    amount:    (float) $amount,
                    notes:     $notes,
                    createdBy: auth()->id(),
                    invoiceId: $invoice->id,
                );

                FinanceTransaction::create([
                    'type'             => 'refund',
                    'direction'        => 'debit',
                    'source_type'      => Receipt::class,
                    'source_id'        => $receipt->id,
                    'amount'           => $amount,
                    'net_amount'       => $amount,
                    'payment_mode'     => 'wallet',
                    'patient_id'       => $patientId,
                    'status'           => 'active',
                    'transaction_date' => now()->toDateString(),
                    'notes'            => 'Revenue reversed, patient credit restored — ' . $notes,
                    'created_by'       => auth()->id(),
                ]);
            } elseif ($method === 'no_refund') {
                // No money returned — just log the void, amount is forfeited/written off
                FinanceTransaction::create([
                    'type'             => 'refund',
                    'direction'        => 'debit',
                    'source_type'      => Receipt::class,
                    'source_id'        => $receipt->id,
                    'amount'           => $amount,
                    'net_amount'       => 0,
                    'payment_mode'     => $receipt->payment_mode,
                    'patient_id'       => $patientId,
                    'status'           => 'active',
                    'transaction_date' => now()->toDateString(),
                    'notes'            => 'No refund issued — ' . $notes,
                    'created_by'       => auth()->id(),
                ]);
            } elseif ($method === 'wallet') {
                // Full amount credited to patient permanent wallet
                (new WalletService())->credit(
                    patientId : $patientId,
                    amount    : $amount,
                    creditType: 'permanent',
                    notes     : 'Wallet credit — ' . $notes,
                    createdBy : auth()->id()
                );
                FinanceTransaction::create([
                    'type'             => 'refund',
                    'direction'        => 'debit',
                    'source_type'      => Receipt::class,
                    'source_id'        => $receipt->id,
                    'amount'           => $amount,
                    'net_amount'       => $amount,
                    'payment_mode'     => $receipt->payment_mode,
                    'patient_id'       => $patientId,
                    'status'           => 'active',
                    'transaction_date' => now()->toDateString(),
                    'notes'            => 'Wallet credit — ' . $notes,
                    'created_by'       => auth()->id(),
                ]);

            } elseif ($method === 'cash') {
                // Physical cash returned — log as refund debit, no wallet change
                FinanceTransaction::create([
                    'type'             => 'refund',
                    'direction'        => 'debit',
                    'source_type'      => Receipt::class,
                    'source_id'        => $receipt->id,
                    'amount'           => $amount,
                    'net_amount'       => $amount,
                    'payment_mode'     => 'cash',
                    'patient_id'       => $patientId,
                    'status'           => 'active',
                    'transaction_date' => now()->toDateString(),
                    'notes'            => 'Cash refund — ' . $notes,
                    'created_by'       => auth()->id(),
                ]);

            } elseif ($method === 'bank_transfer') {
                // Bank transfer / UPI refund.
                // Charge rate auto-determined from original payment mode:
                //   card / debit_card → 2.5% | all others (upi, netbanking, cheque…) → 0%
                $chargeNote = $chargeDeducted > 0
                    ? ' (₹' . number_format($refundAmount, 2) . ' to patient, ₹' . number_format($chargeDeducted, 2) . ' clinic charge)'
                    : ' (no charge)';
                FinanceTransaction::create([
                    'type'             => 'refund',
                    'direction'        => 'debit',
                    'source_type'      => Receipt::class,
                    'source_id'        => $receipt->id,
                    'amount'           => $amount,
                    'net_amount'       => $refundAmount,
                    'payment_mode'     => $receipt->payment_mode,
                    'patient_id'       => $patientId,
                    'status'           => 'active',
                    'transaction_date' => now()->toDateString(),
                    'notes'            => 'Bank transfer refund' . $chargeNote . ' — ' . $notes,
                    'created_by'       => auth()->id(),
                ]);
            }
        });

        $chargeRate = $this->refundChargeRate($receipt->payment_mode);
        $actionMsg  = match($request->void_refund_method) {
            'wallet'        => ' ₹' . number_format($receipt->amount, 2) . ' credited to patient wallet.',
            'cash'          => ' Cash refund of ₹' . number_format($receipt->amount, 2) . ' recorded.',
            'bank_transfer' => $chargeRate > 0
                                ? ' Bank transfer: patient receives ₹' . number_format($receipt->amount * (1 - $chargeRate / 100), 2) . ' (' . $chargeRate . '% charge deducted).'
                                : ' Bank transfer refund of ₹' . number_format($receipt->amount, 2) . ' recorded (no charge).',
            'no_refund'     => ' No refund issued — amount written off.',
            default         => '',
        };

        return redirect()->route('billing.show', $invoice->id)
                         ->with('success', 'Receipt ' . $receipt->receipt_number . ' voided.' . $actionMsg);
    }

    // ── Cancel Invoice (with reason) ─────────────────────────────────────────
    // Admin-only. Voids all receipts (credits wallet), deletes Final Bill if any,
    // marks invoice as cancelled. Saves full audit trail.

    public function cancelInvoice(Request $request, Invoice $invoice)
    {
        if (! auth()->user()->isAdminRole()) {
            abort(403, 'Only admins can cancel invoices.');
        }

        $request->validate([
            'cancelled_reason'       => 'required|string|min:5|max:500',
            'cancel_refund_method'   => 'required|in:wallet,cash,bank_transfer,no_refund',
        ]);

        DB::transaction(function () use ($request, $invoice) {
            $patientId = $invoice->patient_id;
            $method    = $request->cancel_refund_method;

            // 1. Audit log
            BillingAuditLog::record(
                'cancel_invoice',
                $invoice,
                $request->cancelled_reason . ' [refund: ' . $method . ']',
                auth()->id(),
                $invoice->invoice_number
            );

            // 2. Void every active receipt on this invoice
            $activeReceipts = $invoice->receipts()->whereNull('deleted_at')->get();
            foreach ($activeReceipts as $receipt) {
                $amount = (float) $receipt->amount;

                // bank_transfer charge is auto-determined from original payment mode:
                //   card / debit_card → 2.5% | all others (upi, cash-cancelled-as-transfer, etc.) → 0%
                $chargeDeducted = 0;
                $refundAmount   = $amount;
                if ($method === 'bank_transfer') {
                    $chargeDeducted = round($amount * $this->refundChargeRate($receipt->payment_mode) / 100, 2);
                    $refundAmount   = $amount - $chargeDeducted;
                }

                $notes = 'Invoice ' . $invoice->invoice_number . ' cancelled. Reason: ' . $request->cancelled_reason;

                // Save void audit on the payment record
                if ($receipt->invoice_payment_id) {
                    $payment = InvoicePayment::find($receipt->invoice_payment_id);
                    if ($payment) {
                        $payment->update([
                            'void_reason'          => $request->cancelled_reason,
                            'voided_by'            => auth()->id(),
                            'void_refund_method'   => $method,
                            'void_refund_amount'   => $refundAmount,
                            'void_charge_deducted' => $chargeDeducted,
                        ]);
                        FinanceTransaction::where('source_type', InvoicePayment::class)
                            ->where('source_id', $payment->id)
                            ->where('status', 'active')
                            ->update(['status' => 'voided']);
                        $payment->delete();
                    }
                }

                $receipt->delete();

                // Credit / refund / no refund
                if ($method === 'no_refund') {
                    // No money returned — just log the write-off
                    FinanceTransaction::create([
                        'type'             => 'refund',
                        'direction'        => 'debit',
                        'source_type'      => Receipt::class,
                        'source_id'        => $receipt->id,
                        'amount'           => $amount,
                        'net_amount'       => 0,
                        'payment_mode'     => $receipt->payment_mode,
                        'patient_id'       => $patientId,
                        'status'           => 'active',
                        'transaction_date' => now()->toDateString(),
                        'notes'            => 'No refund issued — ' . $notes,
                        'created_by'       => auth()->id(),
                    ]);
                } else {
                    if ($method === 'wallet') {
                        (new WalletService())->credit(
                            patientId : $patientId,
                            amount    : $amount,
                            creditType: 'permanent',
                            notes     : 'Wallet credit — ' . $notes,
                            createdBy : auth()->id()
                        );
                    }

                    $methodLabel = match($method) {
                        'wallet'        => 'Wallet credit',
                        'cash'          => 'Cash refund',
                        'bank_transfer' => $chargeDeducted > 0
                            ? 'Bank transfer refund (₹' . number_format($refundAmount, 2) . ' to patient, ₹' . number_format($chargeDeducted, 2) . ' clinic charge)'
                            : 'Bank transfer refund (no charge)',
                        default         => ucfirst($method) . ' refund',
                    };
                    FinanceTransaction::create([
                        'type'             => 'refund',
                        'direction'        => 'debit',
                        'source_type'      => Receipt::class,
                        'source_id'        => $receipt->id,
                        'amount'           => $amount,
                        'net_amount'       => $refundAmount,
                        'payment_mode'     => $method === 'cash' ? 'cash' : $receipt->payment_mode,
                        'patient_id'       => $patientId,
                        'status'           => 'active',
                        'transaction_date' => now()->toDateString(),
                        'notes'            => $methodLabel . ' — ' . $notes,
                        'created_by'       => auth()->id(),
                    ]);
                }
            }

            // 3. Auto-delete Final Bill if present
            if ($invoice->finalBill) {
                $invoice->finalBill->update([
                    'deleted_reason' => 'Invoice ' . $invoice->invoice_number . ' cancelled. Reason: ' . $request->cancelled_reason,
                    'deleted_by'     => auth()->id(),
                ]);
                $invoice->finalBill->delete();
            }

            // 4. Reverse any retail-product stock deductions this invoice made
            $this->reverseRetailStockMovements($invoice);

            // 4b. Reverse any wallet credit that was debited against this invoice
            $this->reverseInvoiceWalletDebit($invoice, 'invoice ' . $invoice->invoice_number . ' cancelled. ' . $request->cancelled_reason);

            // 4c. S1 — release the treatment-plan teeth this invoice billed and
            // reopen the plan if billing had closed it. Money is being refunded
            // above; the clinical plan must go back to billable in step with it.
            app(PlanBillingRollbackService::class)->rollbackInvoice($invoice);

            // 5. Mark invoice as cancelled + save audit
            $invoice->update([
                'status'           => 'cancelled',
                'cancelled_reason' => $request->cancelled_reason,
                'cancelled_by'     => auth()->id(),
            ]);
            $invoice->delete(); // soft-delete (moves to Trash tab)
        });

        return redirect()->route('finance.income')
                         ->with('success', 'Invoice ' . $invoice->invoice_number . ' cancelled and moved to Trash.');
    }

    // ── Delete Final Bill (with reason) ──────────────────────────────────────
    // Admin-only. Soft-deletes the Final Bill only.
    // Invoice and receipts are NOT affected — invoice stays Paid.
    // Use case: bill generated with wrong discount / before treatment complete.

    public function deleteFinalBill(Request $request, \App\Models\FinalBill $finalBill)
    {
        if (! auth()->user()->isAdminRole()) {
            abort(403, 'Only admins can delete final bills.');
        }

        $request->validate([
            'deleted_reason' => 'required|string|min:5|max:500',
        ]);

        BillingAuditLog::record(
            'delete_final_bill',
            $finalBill,
            $request->deleted_reason,
            auth()->id(),
            $finalBill->bill_number
        );

        $finalBill->update([
            'deleted_reason' => $request->deleted_reason,
            'deleted_by'     => auth()->id(),
        ]);
        $finalBill->delete();

        return redirect()->route('finance.income', ['tab' => 'bills'])
                         ->with('success', 'Final bill ' . $finalBill->bill_number . ' deleted. Invoice and payments are unaffected.');
    }

    // ── Invoice Panel (AJAX partial for patient profile drawer) ──────────────
    // Returns self-contained HTML — no layout. Loaded by the slide-over in patients/show.

    public function panel(Invoice $invoice)
    {
        $invoice->load(['patient', 'items', 'payments', 'receipts', 'finalBill']);

        $activeEmiProviders = \App\Models\EmiProvider::where('is_active', true)
            ->with(['schemes' => fn($q) => $q->where('is_active', true)])
            ->orderBy('name')->get();

        return view('billing._invoice_panel', compact('invoice', 'activeEmiProviders'));
    }

    // ── Show Receipt ─────────────────────────────────────────────────────────

    public function showReceipt(Invoice $invoice, Receipt $receipt)
    {
        if ($receipt->invoice_id !== $invoice->id) {
            abort(403, 'Receipt does not belong to this invoice.');
        }

        $receipt->load(['invoice.patient', 'invoice.items', 'payment']);

        $clinic = \App\Models\AppSetting::whereIn('key', [
            'clinic_name', 'clinic_address', 'clinic_phone', 'clinic_email', 'clinic_gst_no'
        ])->pluck('value', 'key');

        return view('billing.receipt', compact('receipt', 'clinic'));
    }

    // ── Patient-level payment allocation ─────────────────────────────────────

    /**
     * Record ONE tender for a patient and let the system decide which invoices
     * it pays: oldest first, surplus to Patient Credit.
     *
     * Staff never picks an invoice. The per-invoice recordPayment() above is
     * untouched and remains the path for EMI and card-convenience-fee payments.
     */
    public function recordPatientPayment(Request $request, Patient $patient)
    {
        $validated = $request->validate([
            'amount'            => 'required|numeric|min:0.01',
            'payment_mode'      => 'required|in:' . implode(',', PatientPaymentAllocationService::ALLOWED_MODES),
            'payment_date'      => 'required|date',
            'reference_no'      => 'nullable|string|max:100',
            'notes'             => 'nullable|string|max:500',
            'clinic_account_id' => 'nullable|integer|exists:finance_bank_accounts,id',
            'bank_name'         => 'nullable|string|max:120',
            'cheque_no'         => 'nullable|string|max:50',
            'cheque_date'       => 'nullable|date',
        ]);

        $allocator = app(PatientPaymentAllocationService::class);

        if ($allocator->outstandingFor($patient) <= 0 && (float) $validated['amount'] > 0) {
            // Nothing owed — this is a pure advance. Send it down the U8 path so
            // it lands as a liability with its own ADV- receipt, rather than
            // minting an allocation receipt that allocates to nothing.
            (new WalletService())->receiveAdvance(
                patient:     $patient,
                amount:      (float) $validated['amount'],
                paymentMode: $validated['payment_mode'],
                paymentDate: $validated['payment_date'],
                notes:       $validated['notes'] ?? null,
                createdBy:   auth()->id(),
            );

            return back()->with('success',
                '₹' . number_format((float) $validated['amount'], 2)
                . ' received as patient credit — no outstanding invoices to settle.');
        }

        $result = $allocator->allocate($patient, $validated, auth()->id());

        $msg = '₹' . number_format($result['tender'], 2) . ' received. Receipt '
             . $result['receipt']->receipt_number . ' generated.';

        if (count($result['allocations']) > 0) {
            $msg .= ' Allocated across ' . count($result['allocations']) . ' invoice(s): ₹'
                  . number_format($result['settled'], 2) . '.';
        }
        if ($result['surplus'] > 0) {
            $msg .= ' ₹' . number_format($result['surplus'], 2)
                  . ' held as patient credit (not revenue).';
        }
        if ($result['outstanding_after'] > 0) {
            $msg .= ' Outstanding remaining: ₹' . number_format($result['outstanding_after'], 2) . '.';
        } else {
            $msg .= ' Outstanding cleared.';
        }

        return back()->with('success', $msg);
    }

    /**
     * A2 — correct/reverse a consolidated PAY- tender.
     *
     * VOID IS NOT REFUND. Nothing here returns money. Admin-only, matching the
     * existing invoice-receipt void gate exactly — an ordinary finance-view user
     * has no reversal authority.
     */
    public function voidPatientReceipt(Request $request, Patient $patient, Receipt $receipt)
    {
        if ((int) $receipt->patient_id !== (int) $patient->id) {
            abort(403, 'Receipt does not belong to this patient.');
        }

        if (! auth()->user()->isAdminRole()) {
            abort(403, 'Only admins can reverse a payment.');
        }

        $validated = $request->validate([
            'correction_type' => 'required|in:' . implode(',', PatientPaymentVoidService::CORRECTION_TYPES),
            'void_reason'     => 'required|string|min:5|max:500',
        ]);

        $result = app(PatientPaymentVoidService::class)->void(
            receipt:        $receipt,
            correctionType: $validated['correction_type'],
            reason:         $validated['void_reason'],
            userId:         auth()->id(),
        );

        if ($result['already_voided']) {
            return back()->with('success',
                'Receipt ' . $receipt->receipt_number . ' was already reversed — nothing changed.');
        }

        $msg = 'Receipt ' . $receipt->receipt_number . ' reversed. ₹'
             . number_format($result['reversed'], 2) . ' removed from '
             . count($result['invoices']) . ' invoice(s).';

        if ($result['credit_held'] > 0) {
            $msg .= ' ₹' . number_format($result['credit_held'], 2)
                  . ' is now held as patient credit — apply it to the correct invoice. No refund was issued.';
        }
        if ($result['credit_reversed'] > 0) {
            $msg .= ' ₹' . number_format($result['credit_reversed'], 2)
                  . ' of patient credit removed (never received).';
        }

        return back()->with('success', $msg);
    }

    /**
     * Print view for a consolidated allocation receipt. It belongs to a patient,
     * not to a single invoice, so it gets its own route rather than being forced
     * through billing.receipt (which requires $receipt->invoice).
     */
    public function showAllocationReceipt(Patient $patient, Receipt $receipt)
    {
        if ((int) $receipt->patient_id !== (int) $patient->id) {
            abort(403, 'Receipt does not belong to this patient.');
        }

        $receipt->load('patient');

        $clinic = \App\Models\AppSetting::whereIn('key', [
            'clinic_name', 'clinic_address', 'clinic_phone', 'clinic_email', 'clinic_gst_no'
        ])->pluck('value', 'key');

        return view('billing.allocation-receipt', compact('receipt', 'clinic'));
    }

    // ── Show Final Bill ───────────────────────────────────────────────────────

    public function showFinalBill(Invoice $invoice)
    {
        $finalBill = $invoice->finalBill;

        if (!$finalBill) {
            return redirect()->route('billing.show', $invoice)
                ->with('error', 'Final bill has not been generated yet. Pay the full balance first.');
        }

        $invoice->load(['patient', 'items', 'payments', 'receipts']);

        $clinic = \App\Models\AppSetting::whereIn('key', [
            'clinic_name', 'clinic_address', 'clinic_phone', 'clinic_email', 'clinic_gst_no'
        ])->pluck('value', 'key');

        return view('billing.final-bill', compact('invoice', 'finalBill', 'clinic'));
    }

    // ── Enroll Patient in Membership ─────────────────────────────────────────
    // POST from patient profile billing tab enrollment modal.

    public function enrollMembership(Request $request, Patient $patient)
    {
        $request->validate([
            'plan_id'                   => 'required|exists:finance_membership_plans,id',
            'amount_paid'               => 'required|numeric|min:0',
            'payment_mode'              => 'required|in:cash,upi,card,debit_card,netbanking,bank_transfer',
            'family_head_membership_id' => 'nullable|exists:finance_patient_memberships,id',
            'family_name'               => 'nullable|string|max:100',
            'start_date'                => 'nullable|date|before_or_equal:today', // backdated entry allowed, no future dates
            // Default is to invoice the membership fee as outstanding — staff
            // must explicitly tick this to record it as collected right now.
            'collect_now'               => 'nullable|boolean',
        ]);

        // Enrollment date — defaults to today, but can be backdated.
        // Used for the membership validity AND all finance records (invoice/payment/receipt/transaction).
        $enrollDate = $request->filled('start_date')
            ? $request->input('start_date')
            : now()->toDateString();

        $familyHeadId = $request->input('family_head_membership_id');
        $familyName   = trim($request->input('family_name', '')) ?: null;

        // No "family head" concept: if a member is linked, this enrollment is an
        // add-on under them; otherwise it's a standalone member.
        $memberType   = $familyHeadId ? 'addon' : 'individual';

        // Guard: add-on must point at a real, currently-active member (any plan/price).
        if ($memberType === 'addon') {
            $headEnrollment = \App\Models\Finance\FinancePatientMembership::find($familyHeadId);
            if (! $headEnrollment || ! $headEnrollment->isActive()) {
                return back()->withErrors(['family_head_membership_id' => 'The selected member does not have an active membership.'])->withInput();
            }
            // Guard: check max add-ons not exceeded
            $plan = \App\Models\Finance\FinanceMembershipPlan::find($request->plan_id);
            if ($plan && $plan->isAddonModel()) {
                $currentAddons = $headEnrollment->familyMembers()->where('status', 'active')->count();
                if ($currentAddons >= ($plan->max_family_members ?? 4)) {
                    return back()->withErrors(['family_head_membership_id' => 'This family has reached the maximum allowed add-on members.'])->withInput();
                }
            }
            // Inherit family_name from head if not given
            if (! $familyName) {
                $familyName = $headEnrollment->family_name;
            }
        }

        // Enroll + create the membership invoice via the shared service (same
        // one the mobile API uses), so web and mobile always produce identical
        // records. Delegating here also removes ~90 lines of duplicated
        // finance-chain code that used to live in this controller.
        //
        // By default the fee is invoiced as outstanding (draft), not
        // auto-collected — see MembershipBenefitService::enrollWithFinance()
        // for the reasoning. Staff tick "Collected now" in the enroll modal
        // to record it as paid immediately instead.
        $collectNow = $request->boolean('collect_now');

        $result = MembershipBenefitService::enrollWithFinance(
            $patient->id,
            (int) $request->plan_id,
            (float) $request->amount_paid,
            $request->payment_mode,
            Auth::id(),
            $memberType,
            $familyHeadId ? (int) $familyHeadId : null,
            $familyName,
            $enrollDate,   // backdated enrollment date (or today)
            $collectNow
        );

        $invoice = $result['invoice'];

        if ($collectNow) {
            return redirect()->route('billing.print', $invoice->id)
                             ->with('success', 'AOCP Membership enrolled. Receipt generated.');
        }

        return redirect()->route('patients.show', $patient->id)->with('success',
            'AOCP Membership enrolled. Rs. ' . number_format((float) $request->amount_paid, 2)
            . ' added to outstanding dues — collect it from the Billing tab when received.'
        );
    }

    // ── Delete Invoice with Auth ─────────────────────────────────────────────
    // Requires reason text + login password. Logs to billing_audit_logs.
    // Paid invoices are blocked — they need a manager override (future feature).

    public function destroyWithAuth(Request $request, Invoice $invoice)
    {
        $request->validate([
            'reason'   => 'required|string|min:5|max:500',
            'password' => 'required|string',
        ]);

        // Verify caller's password
        if (! Hash::check($request->password, auth()->user()->password)) {
            return back()->withErrors(['password' => 'Incorrect password — deletion not authorised.'])
                         ->withInput();
        }

        // Hard block on paid invoices
        if ($invoice->status === 'paid') {
            return back()->with('error', 'Paid invoices cannot be deleted. Reverse the payments first or contact the administrator.');
        }

        $patientId  = $invoice->patient_id;
        $displayRef = $invoice->invoice_number ?? ('Invoice #' . $invoice->id);

        // Snapshot + audit log BEFORE soft-delete
        BillingAuditLog::record('delete', $invoice, $request->reason, auth()->id(), $displayRef);

        // S1 — release any treatment-plan teeth this invoice billed.
        app(PlanBillingRollbackService::class)->rollbackInvoice($invoice);

        $invoice->delete();

        return redirect()
            ->route('patients.show', $patientId)
            ->with('success', "Invoice {$displayRef} deleted. Reason recorded in audit log.");
    }

    // ── Gate Edit with Auth ──────────────────────────────────────────────────
    // POST to this route before the user is allowed onto the edit form.
    // Validates reason + password, stores reason in session, then redirects to edit.

    public function editWithAuth(Request $request, Invoice $invoice)
    {
        $request->validate([
            'reason'   => 'required|string|min:5|max:500',
            'password' => 'required|string',
        ]);

        if (! Hash::check($request->password, auth()->user()->password)) {
            return back()->withErrors(['password' => 'Incorrect password — edit not authorised.'])
                         ->withInput();
        }

        if ($invoice->status === 'paid') {
            return back()->with('error', 'Paid invoices cannot be edited. Record a credit/adjustment instead.');
        }

        // Log the intent; snapshot will be updated again on actual save
        BillingAuditLog::record('edit_intent', $invoice, $request->reason, auth()->id(), $invoice->invoice_number);

        // Store reason so update() can attach it to the final audit entry
        session(['invoice_edit_reason_' . $invoice->id => $request->reason]);

        return redirect()->route('billing.edit', $invoice)
            ->with('info', 'Edit authorised. Reason: "' . $request->reason . '"');
    }

    // ── AJAX: Get membership benefits for a patient ───────────────────────────
    // Called when front desk changes the patient on invoice form.
    // Returns JSON benefit summary for auto-applying to totals.

    public function membershipBenefits(Request $request)
    {
        $request->validate(['patient_id' => 'required|integer|exists:patients,id']);

        // Parse line items from request if provided (for accurate free-item matching).
        // FMCG/retail product rows (carrying inventory_item_id) never receive AOCP
        // membership benefits — any discount on those rows is manual, entered
        // directly on the invoice line. Only treatment/procedure rows count here.
        $lineItems = [];
        $eligibleSubtotal = 0.0;
        foreach ($request->input('items', []) as $row) {
            if (!empty($row['inventory_item_id'])) {
                continue;
            }
            if (!empty($row['description'])) {
                $amount = (float) ($row['unit_price'] ?? 0);
                $qty    = (int) ($row['qty'] ?? 1);
                $lineItems[] = [
                    'name'   => $row['description'],
                    'amount' => $amount,
                    'qty'    => $qty,
                ];
                $eligibleSubtotal += $amount * $qty;
            }
        }

        $result = MembershipBenefitService::forPatient(
            (int) $request->patient_id,
            $lineItems,
            $eligibleSubtotal
        );

        return response()->json($result);
    }

    // ── Print ────────────────────────────────────────────────────────────────

    public function printInvoice(Invoice $invoice)
    {
        $invoice->load(['patient', 'items', 'payments']);

        // Fetch clinic settings for the header
        $clinic = \App\Models\AppSetting::whereIn('key', [
            'clinic_name', 'clinic_address', 'clinic_phone', 'clinic_email', 'clinic_gst_no'
        ])->pluck('value', 'key');

        return view('billing.print', compact('invoice', 'clinic'));
    }
}
