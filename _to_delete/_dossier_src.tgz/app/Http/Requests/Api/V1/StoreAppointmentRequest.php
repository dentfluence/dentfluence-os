<?php

namespace App\Http\Requests\Api\V1;

use App\Http\Requests\Api\ApiFormRequest;
use App\Services\AppointmentService;

/**
 * StoreAppointmentRequest
 * -----------------------
 * Validation for POST /api/v1/appointments — booking a scheduled appointment
 * for an EXISTING patient. Fails in the standard API envelope (422).
 */
class StoreAppointmentRequest extends ApiFormRequest
{
    public function rules(): array
    {
        return [
            'patient_id'            => ['required', 'integer', 'exists:patients,id'],
            'doctor_id'             => ['required', 'integer', 'exists:users,id'],
            'appointment_date'      => ['required', 'date'],
            'appointment_time'      => ['required', 'string', 'max:8'],
            // Canonical duration + type rules (Slice 6) — shared with the web so
            // the API accepts the same bounds and the same types (incl. follow-up).
            'duration_minutes'      => AppointmentService::durationRule(),
            'type'                  => ['nullable', AppointmentService::typeRule()],
            'treatment_category_id' => ['nullable', 'integer', 'exists:treatment_categories,id'],
            'treatment_id'          => ['nullable', 'integer', 'exists:treatments,id'],
            'operatory_id'          => ['nullable', 'integer', 'exists:operatories,id'],
            'notes'                 => ['nullable', 'string', 'max:1000'],
            'chief_complaint'       => ['nullable', 'string', 'max:1000'],
            // Explicit opt-in to double-book a doctor who already has an
            // overlapping appointment. Without it the service rejects (422).
            'allow_overlap'         => ['nullable', 'boolean'],
        ];
    }
}
